import { describe, expect, it, vi, afterEach } from 'vitest';
import { ChromeAuth, DriveApiError, DriveClient, type TokenProvider } from './driveClient';

const file = { id: 'copied', name: 'File', mimeType: 'text/plain' };
function json(value: unknown, status = 200, headers?: HeadersInit): Response { return new Response(JSON.stringify(value), { status, headers }); }
function apiError(status: number, reason: string, message = reason): Response { return json({ error: { message, errors: [{ reason }] } }, status); }
function setup(responses: Array<Response | Error>, maxRetries = 3) {
  const auth: TokenProvider = { getToken: vi.fn().mockResolvedValue('token'), refreshToken: vi.fn().mockResolvedValue('new-token') };
  const fetcher = vi.fn().mockImplementation(async () => {
    const response = responses.shift();
    if (!response) throw new Error('Unexpected request');
    if (response instanceof Error) throw response;
    return response;
  });
  const sleep = vi.fn().mockResolvedValue(undefined);
  const drive = new DriveClient(auth, { fetch: fetcher as typeof fetch, sleep, random: () => 0.25, maxRetries });
  return { auth, fetcher, sleep, drive };
}
afterEach(() => vi.unstubAllGlobals());

describe('DriveClient', () => {
  it('binds native browser fetch to the global receiver', async () => {
    const nativeFetch = vi.fn(function(this: unknown) {
      if (this !== globalThis) throw new TypeError('Illegal invocation');
      return Promise.resolve(json(file));
    });
    vi.stubGlobal('fetch', nativeFetch);
    const auth: TokenProvider = { getToken: vi.fn().mockResolvedValue('token'), refreshToken: vi.fn() };
    await expect(new DriveClient(auth).getFile('a')).resolves.toEqual(file);
    expect(nativeFetch).toHaveBeenCalledTimes(1);
  });
  it('bounds login profile retries and preserves the transport error', async () => {
    const { drive, fetcher } = setup([new TypeError('Failed to fetch'), new TypeError('Failed to fetch')]);
    await expect(drive.getAccount()).rejects.toThrow('TypeError: Failed to fetch');
    expect(fetcher).toHaveBeenCalledTimes(2);
  });
  it('refreshes a rejected token once after 401', async () => {
    const { drive, auth, fetcher } = setup([apiError(401, 'authError'), json(file)]);
    await expect(drive.getFile('a')).resolves.toEqual(file);
    expect(auth.refreshToken).toHaveBeenCalledExactlyOnceWith('token');
    expect(fetcher).toHaveBeenCalledTimes(2);
  });
  it('does not loop forever after a second 401', async () => {
    const { drive, auth } = setup([apiError(401, 'authError'), apiError(401, 'authError')]);
    await expect(drive.getFile('a')).rejects.toMatchObject({ authRequired: true });
    expect(auth.refreshToken).toHaveBeenCalledTimes(1);
  });
  it.each([[429, 'rateLimitExceeded'], [500, 'backendError'], [503, 'backendError'], [403, 'rateLimitExceeded'], [403, 'userRateLimitExceeded']])('backs off on HTTP %i %s', async (status, reason) => {
    const { drive, sleep } = setup([apiError(status, reason), apiError(status, reason), json(file)]);
    await expect(drive.getFile('a')).resolves.toEqual(file);
    expect(sleep.mock.calls.map(call => call[0])).toEqual([1250, 2250]);
  });
  it('honors Retry-After for rejected rate-limited requests', async () => {
    const { drive, sleep } = setup([json({ error: {} }, 429, { 'Retry-After': '4' }), json(file)]);
    await drive.getFile('a');
    expect(sleep).toHaveBeenCalledExactlyOnceWith(4000);
  });
  it('bounds retries and does not retry ordinary permission failures', async () => {
    const limited = setup([apiError(429, 'rateLimitExceeded'), apiError(429, 'rateLimitExceeded')], 1);
    await expect(limited.drive.getFile('a')).rejects.toBeInstanceOf(DriveApiError);
    expect(limited.fetcher).toHaveBeenCalledTimes(2);
    const denied = setup([apiError(403, 'insufficientFilePermissions')]);
    await expect(denied.drive.getFile('a')).rejects.toMatchObject({ status: 403, fatal: false });
    expect(denied.fetcher).toHaveBeenCalledTimes(1);
  });
  it.each(['storageQuotaExceeded', 'dailyLimitExceeded', 'dailyCopyLimitExceeded'])('fails clearly on %s without retry', async reason => {
    const { drive, fetcher } = setup([apiError(403, reason)]);
    await expect(drive.getFile('a')).rejects.toMatchObject({ fatal: true, reasons: [reason] });
    expect(fetcher).toHaveBeenCalledTimes(1);
  });
  it('sets enumeration query, pagination, shared-drive flags and resource-key header', async () => {
    const { drive, fetcher } = setup([json({ files: [], nextPageToken: 'next' })]);
    await drive.listChildren('source', 'page', 'key');
    const url = new URL(fetcher.mock.calls[0][0]);
    expect(url.searchParams.get('q')).toBe("'source' in parents and trashed=false");
    expect(url.searchParams.get('pageSize')).toBe('1000');
    expect(url.searchParams.get('pageToken')).toBe('page');
    expect(url.searchParams.get('supportsAllDrives')).toBe('true');
    expect(url.searchParams.get('includeItemsFromAllDrives')).toBe('true');
    expect(fetcher.mock.calls[0][1].headers['X-Goog-Drive-Resource-Keys']).toBe('source/key');
  });
  it('does not silently accept incomplete search results', async () => {
    const { drive } = setup([json({ files: [], incompleteSearch: true })]);
    await expect(drive.listChildren('source')).rejects.toThrow('chưa đầy đủ');
  });
  it('copies server-side with parent and durable operation marker', async () => {
    const { drive, fetcher } = setup([json(file)]);
    await drive.copyFile({ sourceId: 'original', parentId: 'dest', name: 'Copy', operationId: 'op', resourceKey: 'rk' });
    const [url, request] = fetcher.mock.calls[0];
    expect(new URL(url).pathname).toBe('/drive/v3/files/original/copy');
    expect(request.method).toBe('POST');
    expect(JSON.parse(request.body)).toEqual({ name: 'Copy', parents: ['dest'], appProperties: { driveCopierOp: 'op' } });
    expect(request.headers['X-Goog-Drive-Resource-Keys']).toBe('original/rk');
  });
  it('recovers a committed copy after 503 through marker without another POST', async () => {
    const { drive, fetcher } = setup([apiError(503, 'backendError'), json({ files: [file] })]);
    await expect(drive.copyFile({ sourceId: 'original', parentId: 'dest', name: 'Copy', operationId: 'op' })).resolves.toEqual(file);
    expect(fetcher.mock.calls.filter(call => call[1].method === 'POST')).toHaveLength(1);
    expect(new URL(fetcher.mock.calls[1][0]).searchParams.get('q')).toContain("value='op'");
  });
  it('reconciles server-error copies and pauses instead of risking a duplicate', async () => {
    const { drive, fetcher } = setup([apiError(500, 'backendError'), json({ files: [] }), json({ files: [] }), json({ files: [] })]);
    await expect(drive.copyFile({ sourceId: 'original', parentId: 'dest', name: 'Copy', operationId: 'op' })).rejects.toMatchObject({ uncertain: true });
    expect(fetcher.mock.calls.filter(call => call[1].method === 'POST')).toHaveLength(1);
  });
  it('safe-retries an explicitly rejected 429 copy after marker reconciliation', async () => {
    const { drive, fetcher } = setup([apiError(429, 'rateLimitExceeded'), json({ files: [] }), json(file)]);
    await expect(drive.copyFile({ sourceId: 'original', parentId: 'dest', name: 'Copy', operationId: 'op' })).resolves.toEqual(file);
    expect(fetcher.mock.calls.filter(call => call[1].method === 'POST')).toHaveLength(2);
  });
  it('network loss after POST is uncertain and never blindly retried', async () => {
    const { drive, fetcher } = setup([new Error('connection reset')]);
    await expect(drive.createFolder({ parentId: 'dest', name: 'Folder', operationId: 'op' })).rejects.toMatchObject({ uncertain: true });
    expect(fetcher).toHaveBeenCalledTimes(1);
  });
  it('preserves an uncertain outcome when reconciliation itself fails', async () => {
    const { drive, fetcher } = setup([apiError(503, 'backendError'), apiError(403, 'insufficientFilePermissions')]);
    await expect(drive.copyFile({ sourceId: 'original', parentId: 'dest', name: 'Copy', operationId: 'op' })).rejects.toMatchObject({ uncertain: true });
    expect(fetcher.mock.calls.filter(call => call[1].method === 'POST')).toHaveLength(1);
  });
  it('treats server failure as uncertain even with no retries configured', async () => {
    const { drive } = setup([apiError(500, 'backendError')], 0);
    await expect(drive.createFolder({ parentId: 'dest', name: 'Folder', operationId: 'op' })).rejects.toMatchObject({ uncertain: true });
  });
  it('never commits a successful response without a destination ID', async () => {
    const { drive } = setup([json({})]);
    await expect(drive.copyFile({ sourceId: 'original', parentId: 'dest', name: 'Copy', operationId: 'op' })).rejects.toMatchObject({ uncertain: true });
  });
  it('prevents account switching before a mutation', async () => {
    const auth: TokenProvider = { getToken: vi.fn().mockResolvedValue('token'), refreshToken: vi.fn() };
    const fetcher = vi.fn().mockResolvedValue(json({ user: { emailAddress: 'other@example.com', displayName: 'Other', permissionId: 'other' } }));
    const drive = new DriveClient(auth, { fetch: fetcher as typeof fetch, expectedOwner: 'original-owner' });
    await expect(drive.copyFile({ sourceId: 'a', parentId: 'dest', name: 'Copy', operationId: 'op' })).rejects.toMatchObject({ authRequired: true });
    expect(fetcher).toHaveBeenCalledTimes(1);
    expect(new URL(fetcher.mock.calls[0][0]).pathname).toBe('/drive/v3/about');
  });
});

describe('ChromeAuth', () => {
  function chromeMock() {
    const identity = {
      getAuthToken: vi.fn().mockResolvedValue({ token: 'token' }),
      removeCachedAuthToken: vi.fn().mockResolvedValue(undefined),
      clearAllCachedAuthTokens: vi.fn().mockResolvedValue(undefined),
    };
    vi.stubGlobal('chrome', { identity, runtime: { getManifest: () => ({ oauth2: { client_id: 'test.apps.googleusercontent.com' } }) } });
    return identity;
  }
  it('uses interactive login and deduplicates concurrent token refresh', async () => {
    const identity = chromeMock();
    const auth = new ChromeAuth();
    await auth.getToken(true);
    expect(identity.getAuthToken).toHaveBeenCalledWith({ interactive: true });
    await Promise.all([auth.refreshToken('token'), auth.refreshToken('token')]);
    expect(identity.removeCachedAuthToken).toHaveBeenCalledExactlyOnceWith({ token: 'token' });
    expect(identity.getAuthToken).toHaveBeenCalledTimes(2);
  });
  it('removes cached token, revokes access and prevents silent login after logout', async () => {
    const identity = chromeMock();
    const fetcher = vi.fn().mockResolvedValue(new Response('', { status: 200 }));
    vi.stubGlobal('fetch', fetcher);
    const auth = new ChromeAuth();
    await auth.getToken(true);
    await auth.signOut();
    expect(identity.removeCachedAuthToken).toHaveBeenCalledWith({ token: 'token' });
    expect(identity.clearAllCachedAuthTokens).toHaveBeenCalledTimes(1);
    expect(fetcher.mock.calls[0][0]).toBe('https://oauth2.googleapis.com/revoke');
    expect(fetcher.mock.calls[0][1].body.get('token')).toBe('token');
    await expect(auth.getToken(false)).rejects.toMatchObject({ authRequired: true });
  });
});
