import { FOLDER_MIME, type Account, type DriveAdapter, type DriveFile, type FilePage, type MutationInput } from './types';

const API = 'https://www.googleapis.com/drive/v3/';
const FILE_FIELDS = 'id,name,mimeType,parents,resourceKey,webViewLink,shortcutDetails,capabilities(canCopy,canAddChildren)';
const LIST_FIELDS = 'nextPageToken,incompleteSearch,files(id,name,mimeType,resourceKey,shortcutDetails,capabilities/canCopy)';
const RETRY_REASONS = new Set(['rateLimitExceeded', 'userRateLimitExceeded', 'sharingRateLimitExceeded']);
const FATAL_REASONS = new Set(['storageQuotaExceeded', 'dailyLimitExceeded', 'dailyLimitExceededUnreg', 'teamDriveFileLimitExceeded', 'activeItemCreationLimitExceeded', 'copyLimitExceeded', 'dailyCopyLimitExceeded', 'userCopyLimitExceeded']);

export class DriveApiError extends Error {
  constructor(message: string, public status = 0, public reasons: string[] = [], public fatal = false, public authRequired = false, public uncertain = false) {
    super(message);
    this.name = 'DriveApiError';
  }
}

export interface TokenProvider {
  getToken(interactive?: boolean): Promise<string>;
  refreshToken(invalidToken: string): Promise<string>;
}

/** Access tokens live only in Chrome's cache and this worker's memory, never storage. */
export class ChromeAuth implements TokenProvider {
  private token?: string;
  private refreshing?: Promise<string>;
  private enabled = true;

  setEnabled(enabled: boolean): void { this.enabled = enabled; }
  async getToken(interactive = false): Promise<string> {
    if (!this.enabled && !interactive) throw new DriveApiError('Bạn đã đăng xuất. Hãy đăng nhập để tiếp tục.', 401, [], false, true);
    const clientId = chrome.runtime.getManifest().oauth2?.client_id;
    if (!clientId || clientId.startsWith('REPLACE_')) throw new DriveApiError('Chưa cấu hình OAuth clientId. Làm theo README rồi build và Reload extension.', 401, [], false, true);
    try {
      const result = await chrome.identity.getAuthToken({ interactive });
      if (!result.token) throw new Error('Chrome không trả về access token.');
      this.token = result.token;
      this.enabled = true;
      return result.token;
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      throw new DriveApiError(`Không lấy được quyền Drive: ${detail}. Kiểm tra đăng nhập Chrome, OAuth client ID, extension ID và test users.`, 401, [], false, true);
    }
  }
  async refreshToken(invalidToken: string): Promise<string> {
    if (this.refreshing) return this.refreshing;
    this.refreshing = (async () => {
      await chrome.identity.removeCachedAuthToken({ token: invalidToken });
      if (this.token === invalidToken) this.token = undefined;
      return this.getToken(false);
    })();
    try { return await this.refreshing; } finally { this.refreshing = undefined; }
  }
  async signOut(): Promise<void> {
    let token = this.token;
    this.enabled = false;
    if (!token) {
      try { token = (await chrome.identity.getAuthToken({ interactive: false })).token; } catch { /* No token left to revoke. */ }
    }
    this.token = undefined;
    try {
      if (token) {
        await chrome.identity.removeCachedAuthToken({ token });
        const response = await fetch('https://oauth2.googleapis.com/revoke', {
          method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ token }), signal: AbortSignal.timeout(25_000),
        });
        if (!response.ok && response.status !== 400) throw new Error('Không thu hồi được quyền trên Google.');
      }
    } catch {
      throw new Error('Đã đăng xuất cục bộ, nhưng Google chưa xác nhận thu hồi quyền. Kiểm tra mạng hoặc thu hồi trong Tài khoản Google → Kết nối với bên thứ ba.');
    } finally {
      await chrome.identity.clearAllCachedAuthTokens();
    }
  }
}

interface ClientOptions {
  fetch?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
  random?: () => number;
  maxRetries?: number;
  expectedOwner?: string;
}
interface RequestOptions {
  method?: 'GET' | 'POST';
  query?: Record<string, string>;
  body?: unknown;
  resourceKey?: { id: string; key?: string };
  reconcile?: () => Promise<DriveFile | undefined>;
  skipOwnerCheck?: boolean;
  maxRetries?: number;
  timeoutMs?: number;
}

export class DriveClient implements DriveAdapter {
  private readonly fetcher: typeof fetch;
  private readonly sleep: (ms: number) => Promise<void>;
  private readonly random: () => number;
  private readonly maxRetries: number;
  private verifiedToken?: string;
  private verifying?: Promise<void>;
  constructor(private readonly auth: TokenProvider, private readonly options: ClientOptions = {}) {
    // Browser fetch requires its Window/WorkerGlobalScope receiver. Calling
    // an unbound native fetch as this.fetcher throws "Illegal invocation".
    this.fetcher = options.fetch ?? globalThis.fetch.bind(globalThis);
    this.sleep = options.sleep ?? (ms => new Promise(resolve => setTimeout(resolve, ms)));
    this.random = options.random ?? Math.random;
    this.maxRetries = options.maxRetries ?? 5;
  }

  private async verifyOwner(token: string): Promise<void> {
    if (!this.options.expectedOwner || this.verifiedToken === token) return;
    if (!this.verifying) this.verifying = (async () => {
      const account = await this.getAccount();
      if (account.permissionId !== this.options.expectedOwner) throw new DriveApiError('Tài khoản Chrome hiện tại khác tài khoản tạo job. Đăng nhập đúng tài khoản trước khi tiếp tục.', 401, [], false, true);
      // Do not cache the caller's old token if about.get refreshed it after 401.
      this.verifiedToken = await this.auth.getToken(false);
    })();
    try { await this.verifying; } finally { this.verifying = undefined; }
  }

  private async request<T>(path: string, options: RequestOptions = {}): Promise<T> {
    const url = new URL(path, API);
    if (options.query) url.search = new URLSearchParams(options.query).toString();
    let refreshed = false;
    let retries = 0;
    const maxRetries = options.maxRetries ?? this.maxRetries;
    while (true) {
      let token = await this.auth.getToken(false);
      if (!options.skipOwnerCheck) {
        await this.verifyOwner(token);
        token = await this.auth.getToken(false);
      }
      const headers: Record<string, string> = { Authorization: `Bearer ${token}` };
      if (options.body) headers['Content-Type'] = 'application/json';
      if (options.resourceKey?.key) headers['X-Goog-Drive-Resource-Keys'] = `${options.resourceKey.id}/${options.resourceKey.key}`;
      let response: Response;
      try {
        response = await this.fetcher(url, { method: options.method ?? 'GET', headers, body: options.body ? JSON.stringify(options.body) : undefined, signal: AbortSignal.timeout(options.timeoutMs ?? 25_000) });
      } catch (error) {
        // The server may have accepted a POST. No blind POST retry on lost response.
        if (options.method === 'POST') throw new DriveApiError('Mất kết nối khi tạo bản sao; kết quả chưa xác định. Job tạm dừng để đối chiếu bản sao trên Google.', 0, [], false, false, true);
        if (retries++ >= maxRetries) {
          const detail = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
          throw new DriveApiError(`Không kết nối được Google Drive (${detail}). Kiểm tra mạng, VPN/proxy hoặc extension chặn kết nối rồi thử lại.`);
        }
        await this.backoff(retries);
        continue;
      }
      if (response.ok) {
        try { return await response.json() as T; }
        catch { throw new DriveApiError('Không đọc được phản hồi Google. Cần đối chiếu lại kết quả.', response.status, [], false, false, options.method === 'POST'); }
      }
      if (response.status === 401 && !refreshed) {
        await this.auth.refreshToken(token);
        this.verifiedToken = undefined;
        refreshed = true;
        continue;
      }
      const payload = await response.json().catch(() => ({})) as { error?: { message?: string; errors?: { reason?: string }[] } };
      const reasons = payload.error?.errors?.map(error => error.reason ?? '').filter(Boolean) ?? [];
      const originalMessage = payload.error?.message ?? `HTTP ${response.status}`;
      const quota = FATAL_REASONS.has(reasons[0]) || reasons.some(reason => FATAL_REASONS.has(reason)) || /(?:daily|per day|24.hour|750\s*GB).*(?:copy|limit|quota)|copy.*(?:daily|per day|limit exceeded)/i.test(originalMessage);
      if (quota) {
        const storage = reasons.includes('storageQuotaExceeded');
        throw new DriveApiError(storage ? 'Drive đích đã hết dung lượng. Giải phóng dung lượng trước khi tạo job mới.' : 'Google đã chặn vì hạn mức ngày, số bản sao hoặc số lượng mục. Hãy kiểm tra quota và chờ hạn mức được làm mới.', response.status, reasons, true);
      }
      const retry = [429, 500, 503].includes(response.status) || response.status === 403 && reasons.some(reason => RETRY_REASONS.has(reason));
      if (options.method === 'POST' && response.status >= 500) {
        // A server/gateway error can be returned after the write committed.
        // Only poll the marker; never resend an ambiguous write.
        try {
          for (let attempt = 1; attempt <= maxRetries; attempt++) {
            await this.backoff(attempt, response.headers.get('Retry-After'));
            const result = await options.reconcile?.();
            if (result) return result as T;
          }
        } catch (error) {
          const flags = error instanceof DriveApiError ? error : undefined;
          throw new DriveApiError('Không đối soát được request ghi sau lỗi server. Kết quả chưa xác định; hãy kiểm tra Drive trước khi tiếp tục.', response.status, reasons, flags?.fatal, flags?.authRequired, true);
        }
        throw new DriveApiError('Google trả lỗi server khi tạo bản sao. Chưa xác nhận được kết quả; job tạm dừng để tránh copy trùng.', response.status, reasons, false, false, true);
      }
      if (retry && retries++ < maxRetries) {
        await this.backoff(retries, response.headers.get('Retry-After'));
        if (options.reconcile) {
          const recovered = await options.reconcile();
          if (recovered) return recovered as T;
        }
        continue;
      }
      const message = response.status === 401 ? 'Phiên đăng nhập hết hạn. Đăng nhập lại để tiếp tục.' : `Google Drive: ${originalMessage}${reasons.length ? ` (${reasons.join(', ')})` : ''}`;
      throw new DriveApiError(message, response.status, reasons, false, response.status === 401);
    }
  }

  private backoff(attempt: number, retryAfter?: string | null): Promise<void> {
    const seconds = retryAfter ? Number(retryAfter) : 0;
    const dateDelay = retryAfter && !Number.isFinite(seconds) ? Date.parse(retryAfter) - Date.now() : 0;
    return this.sleep(Math.min(64_000, Math.max(2 ** (attempt - 1) * 1000 + this.random() * 1000, Number.isFinite(seconds) ? seconds * 1000 : dateDelay || 0)));
  }
  async getAccount(): Promise<Account> {
    const data = await this.request<{ user: { emailAddress: string; displayName: string; permissionId: string } }>('about', { query: { fields: 'user(emailAddress,displayName,permissionId)' }, skipOwnerCheck: true, maxRetries: 1, timeoutMs: 10_000 });
    if (!data.user?.permissionId || !data.user.emailAddress) throw new DriveApiError('Không đọc được tài khoản Google Drive.', 401, [], false, true);
    return { email: data.user.emailAddress, displayName: data.user.displayName, permissionId: data.user.permissionId };
  }
  getFile(id: string, resourceKey?: string): Promise<DriveFile> {
    return this.request(`files/${encodeURIComponent(id)}`, { query: { supportsAllDrives: 'true', fields: FILE_FIELDS }, resourceKey: { id, key: resourceKey } });
  }
  async listChildren(id: string, pageToken?: string, resourceKey?: string): Promise<FilePage> {
    const page = await this.request<FilePage & { incompleteSearch?: boolean }>('files', { query: {
      q: `'${escapeQuery(id)}' in parents and trashed=false`, fields: LIST_FIELDS,
      pageSize: '1000', supportsAllDrives: 'true', includeItemsFromAllDrives: 'true',
      ...(pageToken ? { pageToken } : {}),
    }, resourceKey: { id, key: resourceKey } });
    if (page.incompleteSearch) throw new DriveApiError('Google trả về danh sách chưa đầy đủ. Job tạm dừng; hãy Tiếp tục khi truy vấn hoàn chỉnh.');
    return page;
  }
  async findByOperation(parentId: string, operationId: string): Promise<DriveFile | undefined> {
    const page = await this.request<FilePage>('files', { query: {
      q: `'${escapeQuery(parentId)}' in parents and trashed=false and appProperties has { key='driveCopierOp' and value='${escapeQuery(operationId)}' }`,
      fields: `nextPageToken,files(${FILE_FIELDS})`, pageSize: '100', supportsAllDrives: 'true', includeItemsFromAllDrives: 'true',
    } });
    if (page.files.length > 1 || page.nextPageToken) throw new DriveApiError('Phát hiện nhiều bản sao có cùng mã thao tác. Hãy kiểm tra thư mục đích; job dừng để tránh copy trùng.', 409, [], true);
    return page.files[0];
  }
  createFolder(input: MutationInput): Promise<DriveFile> { return this.mutate('files', input, true); }
  copyFile(input: MutationInput): Promise<DriveFile> {
    if (!input.sourceId) throw new Error('Thiếu sourceId cho files.copy.');
    return this.mutate(`files/${encodeURIComponent(input.sourceId)}/copy`, input, false);
  }
  private async mutate(path: string, input: MutationInput, folder: boolean): Promise<DriveFile> {
    const result = await this.request<DriveFile>(path, {
      method: 'POST', query: { supportsAllDrives: 'true', fields: FILE_FIELDS },
      body: { name: input.name, parents: [input.parentId], appProperties: { driveCopierOp: input.operationId }, ...(folder ? { mimeType: FOLDER_MIME } : {}) },
      resourceKey: input.sourceId ? { id: input.sourceId, key: input.resourceKey } : undefined,
      reconcile: () => this.findByOperation(input.parentId, input.operationId),
    });
    if (!result.id || typeof result.id !== 'string') throw new DriveApiError('Google chưa trả về ID bản sao. Cần đối soát kết quả trước khi tiếp tục.', 200, [], false, false, true);
    return result;
  }
}

function escapeQuery(value: string): string { return value.replace(/\\/g, '\\\\').replace(/'/g, "\\'"); }
