import { describe, expect, it, vi } from 'vitest';
import { createJob, runCopyJob } from './copyEngine';
import { DriveApiError, DriveClient } from './driveClient';
import {
  FOLDER_MIME, SHORTCUT_MIME, type CopyJob, type DriveAdapter,
  type DriveFile, type FilePage, type MutationInput,
} from './types';

const file = (id: string, extra: Partial<DriveFile> = {}): DriveFile => ({
  id, name: id, mimeType: 'text/plain', capabilities: { canCopy: true }, ...extra,
});
const folder = (id: string, extra: Partial<DriveFile> = {}): DriveFile => file(id, { mimeType: FOLDER_MIME, ...extra });
const shortcut = (id: string, target: string, mimeType = 'text/plain', key?: string): DriveFile => file(id, {
  mimeType: SHORTCUT_MIME,
  shortcutDetails: { targetId: target, targetMimeType: mimeType, targetResourceKey: key },
});

function setup(source = folder('source')) {
  const metadata = new Map<string, DriveFile>([
    ['source', source], ['root', folder('my-drive')], ['my-drive', folder('my-drive')],
  ]);
  const pages = new Map<string, FilePage>();
  const markers = new Map<string, DriveFile>();
  const copies: MutationInput[] = [];
  const folders: MutationInput[] = [];
  let active = 0;
  let maxActive = 0;
  let serial = 0;
  const drive: DriveAdapter = {
    getFile: vi.fn(async (id: string) => {
      const item = metadata.get(id);
      if (!item) throw new Error(`Không truy cập được ${id}`);
      return structuredClone(item);
    }),
    listChildren: vi.fn(async (id: string, token?: string) => structuredClone(pages.get(`${id}:${token ?? ''}`) ?? { files: [] })),
    findByOperation: vi.fn(async (parentId, operationId) => markers.get(`${parentId}:${operationId}`)),
    createFolder: vi.fn(async (input: MutationInput) => {
      folders.push(structuredClone(input));
      const result = folder(`created-${++serial}`, { name: input.name, parents: [input.parentId] });
      markers.set(`${input.parentId}:${input.operationId}`, result);
      return result;
    }),
    copyFile: vi.fn(async (input: MutationInput) => {
      copies.push(structuredClone(input));
      active++;
      maxActive = Math.max(maxActive, active);
      await new Promise(resolve => setTimeout(resolve, 2));
      active--;
      const result = file(`copied-${++serial}`, { name: input.name, parents: [input.parentId] });
      markers.set(`${input.parentId}:${input.operationId}`, result);
      return result;
    }),
  };
  const job = createJob({
    sourceLink: 'https://drive.google.com/drive/folders/source', sourceId: 'source',
    ownerPermissionId: 'owner', ownerEmail: 'owner@example.com',
  });
  const snapshots: CopyJob[] = [];
  const persist = vi.fn(async (state: CopyJob) => { snapshots.push(structuredClone(state)); });
  return { metadata, pages, markers, copies, folders, drive, job, snapshots, persist,
    get maxActive() { return maxActive; }, get active() { return active; } };
}

describe('copyEngine', () => {
  it('copies on Drive, creates folders breadth first, and caps concurrent copies at four', async () => {
    const env = setup();
    env.pages.set('source:', { files: [folder('sub'), ...Array.from({ length: 11 }, (_, i) => file(`f${i}`))] });
    env.pages.set('sub:', { files: [folder('nested'), file('inner')] });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('completed');
    expect(env.copies).toHaveLength(12);
    expect(new Set(env.copies.map(copy => copy.sourceId)).size).toBe(12);
    expect(env.folders.map(item => item.sourceId)).toEqual(['source', 'sub', 'nested']);
    expect(env.maxActive).toBe(4);
    expect(env.active).toBe(0);
    expect(env.job.counts).toEqual({ discovered: 12, copied: 12, folders: 3, skipped: 0 });
    expect(env.job.resultUrl).toContain('/drive/folders/');
    expect(env.snapshots.some(snapshot => Object.values(snapshot.pendingOperations).some(op => op.phase === 'uncertain'))).toBe(true);
  });

  it('resumes a saved page cursor, processes pagination, and never recopies duplicate IDs', async () => {
    const env = setup();
    env.pages.set('source:', { files: [file('first'), file('second')], nextPageToken: 'page-2' });
    env.pages.set('source:page-2', { files: [file('second'), file('third')] });
    let proceed = true;
    await runCopyJob(env.job, env.drive, {
      persist: async state => {
        await env.persist(state);
        if (state.folderQueue[0]?.index === 1) proceed = false;
      },
      shouldContinue: () => proceed,
    });
    expect(env.job.status).toBe('paused');
    expect(env.job.folderQueue[0].page?.nextPageToken).toBe('page-2');
    const resumed = structuredClone(env.snapshots.at(-1)!);
    resumed.status = 'running';
    await runCopyJob(resumed, env.drive, { persist: env.persist });
    expect(resumed.status).toBe('completed');
    expect(env.copies.map(item => item.sourceId).sort()).toEqual(['first', 'second', 'third']);
    expect(env.drive.listChildren).toHaveBeenCalledTimes(2);
    expect(env.drive.listChildren).toHaveBeenLastCalledWith('source', 'page-2', undefined);
  });

  it.each(['file', 'folder'] as const)('reconciles %s committed by Drive before the worker could save its result', async kind => {
    const env = setup(kind === 'file' ? file('source') : folder('source'));
    let durable: CopyJob | undefined;
    let crash = true;
    await expect(runCopyJob(env.job, env.drive, {
      persist: async state => {
        if (state.resultId && crash) { crash = false; throw new Error('worker terminated'); }
        durable = structuredClone(state);
      },
    })).rejects.toThrow('worker terminated');
    expect(durable).toBeDefined();
    expect(Object.values(durable!.pendingOperations)[0].phase).toBe('uncertain');
    expect(durable!.resultId).toBeUndefined();
    const resumed = durable!;
    await runCopyJob(resumed, env.drive, { persist: env.persist });
    expect(resumed.status).toBe('completed');
    expect(env.drive.findByOperation).toHaveBeenCalledTimes(1);
    expect(kind === 'file' ? env.copies : env.folders).toHaveLength(1);
    expect(resumed.counts[kind === 'file' ? 'copied' : 'folders']).toBe(1);
  });

  it('pauses an uncertain request with no marker instead of issuing a blind duplicate', async () => {
    const env = setup(file('source'));
    env.drive.copyFile = vi.fn(async () => {
      throw Object.assign(new Error('Mất kết nối sau khi gửi request.'), { uncertain: true });
    });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('paused');
    env.job.status = 'running';
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('paused');
    expect(env.drive.copyFile).toHaveBeenCalledTimes(1);
    expect(env.job.errors.at(-1)?.message).toContain('tránh copy trùng');
  });

  it('resolves root shortcuts and forwards the target resource key and requested name', async () => {
    const env = setup(shortcut('source', 'target', 'text/plain', 'target-key'));
    env.metadata.set('target', file('target'));
    env.job.newName = 'Tên mới';
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.drive.getFile).toHaveBeenCalledWith('target', 'target-key');
    expect(env.copies[0]).toMatchObject({ sourceId: 'target', resourceKey: 'target-key', parentId: 'my-drive', name: 'Tên mới' });
    expect(env.job.copiedSourceIds).toEqual(['target']);
    expect(env.job.rootKind).toBe('file');
  });

  it('deduplicates shortcut targets, avoids folder cycles, and reports inaccessible shortcut loops', async () => {
    const env = setup();
    env.metadata.set('target', file('target'));
    env.metadata.set('loop-a', shortcut('loop-a', 'loop-b'));
    env.metadata.set('loop-b', shortcut('loop-b', 'loop-a'));
    env.pages.set('source:', { files: [
      shortcut('alias', 'target'), file('target'), shortcut('back', 'source', FOLDER_MIME),
      shortcut('broken-loop', 'loop-a'),
    ] });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('completed');
    expect(env.copies).toHaveLength(1);
    expect(env.folders).toHaveLength(1);
    expect(env.job.errors.some(item => item.message.includes('vòng lặp'))).toBe(true);
    expect(env.job.counts.copied).toBe(1);
  });

  it('skips canCopy=false and keeps the Vietnamese reason in its log', async () => {
    const env = setup();
    env.pages.set('source:', { files: [file('blocked', { capabilities: { canCopy: false } }), file('allowed')] });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.copies.map(item => item.sourceId)).toEqual(['allowed']);
    expect(env.job.counts).toEqual({ discovered: 2, copied: 1, folders: 1, skipped: 1 });
    expect(env.job.errors[0].message.toLowerCase()).toContain('chủ sở hữu chặn copy');
  });

  it('traverses folders with canCopy=false and checks each child permission', async () => {
    const env = setup(folder('source', { capabilities: { canCopy: false } }));
    env.pages.set('source:', { files: [folder('sub', { capabilities: { canCopy: false } })] });
    env.pages.set('sub:', { files: [file('allowed'), file('blocked', { capabilities: { canCopy: false } })] });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('completed');
    expect(env.job.counts).toEqual({ discovered: 2, copied: 1, folders: 2, skipped: 1 });
    expect(env.copies[0].sourceId).toBe('allowed');
  });

  it('runs a job through DriveClient backoff after a mocked HTTP 429, counting exactly one copy', async () => {
    const env = setup(file('source'));
    env.job.sourceResourceKey = 'source-key';
    let copyRequests = 0;
    const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), {
      status, headers: { 'Content-Type': 'application/json' },
    });
    const fetcher = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
      const url = new URL(String(input));
      if (url.pathname.endsWith('/files/source/copy')) {
        expect(new Headers(init?.headers).get('X-Goog-Drive-Resource-Keys')).toBe('source/source-key');
        copyRequests++;
        if (copyRequests === 1) return json({ error: { message: 'Too many requests', errors: [{ reason: 'rateLimitExceeded' }] } }, 429);
        return json(file('result'));
      }
      if (url.pathname.endsWith('/files/source')) return json(file('source'));
      if (url.pathname.endsWith('/files/root')) return json(folder('my-drive'));
      if (url.pathname.endsWith('/files')) return json({ files: [] });
      throw new Error(`Unexpected request: ${url}`);
    });
    const sleep = vi.fn(async (_ms: number) => {});
    const client = new DriveClient({ getToken: async () => 'test-token', refreshToken: async () => 'new-token' }, {
      fetch: fetcher as typeof fetch, sleep, random: () => 0,
    });
    await runCopyJob(env.job, client, { persist: env.persist });
    expect(env.job.status).toBe('completed');
    expect(copyRequests).toBe(2);
    expect(sleep).toHaveBeenCalledWith(1000);
    expect(env.job.counts.copied).toBe(1);
    expect(env.job.copiedSourceIds).toEqual(['source']);
    expect(Object.keys(env.job.pendingOperations)).toHaveLength(0);
  });

  it('preserves a shortcut page cursor when resolving its target exhausts transient GET retries', async () => {
    const env = setup();
    env.pages.set('source:', { files: [shortcut('alias', 'target')] });
    const get = env.drive.getFile;
    env.drive.getFile = vi.fn(async (id, key) => {
      if (id === 'target') throw new DriveApiError('Google tạm thời quá tải.', 503);
      return get(id, key);
    });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('paused');
    expect(env.job.folderQueue[0].index).toBe(0);
    expect(env.job.counts.skipped).toBe(0);
    env.metadata.set('target', file('target'));
    env.drive.getFile = get;
    env.job.status = 'running';
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('completed');
    expect(env.copies[0].sourceId).toBe('target');
  });

  it('retains a prepared file after exhausted rate-limit retries, pauses, and resumes the remaining tree without duplicates', async () => {
    const env = setup();
    env.pages.set('source:', { files: Array.from({ length: 6 }, (_, i) => file(`f${i}`)) });
    const copy = env.drive.copyFile;
    env.drive.copyFile = vi.fn(async input => {
      if (input.sourceId === 'f0') throw new DriveApiError('Google vẫn giới hạn request.', 403, ['userRateLimitExceeded']);
      return copy(input);
    });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('paused');
    expect(env.job.counts.copied).toBe(3);
    expect(env.job.counts.skipped).toBe(0);
    expect(Object.values(env.job.pendingOperations)).toMatchObject([{ sourceId: 'f0', phase: 'prepared' }]);
    expect(env.job.folderQueue[0].index).toBe(4);
    env.drive.copyFile = copy;
    env.job.status = 'running';
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('completed');
    expect(env.job.counts.copied).toBe(6);
    expect(new Set(env.copies.map(item => item.sourceId)).size).toBe(6);
    expect(env.copies).toHaveLength(6);
    expect(env.drive.findByOperation).not.toHaveBeenCalled();
  });

  it('pauses authentication failure during initialization so sign-in can resume the same job', async () => {
    const env = setup(file('source'));
    const get = env.drive.getFile;
    env.drive.getFile = vi.fn(async () => { throw new DriveApiError('Hãy đăng nhập lại.', 401, [], false, true); });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('paused');
    expect(env.job.initialized).toBe(false);
    env.drive.getFile = get;
    env.job.status = 'running';
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('completed');
    expect(env.copies).toHaveLength(1);
  });

  it('settles all in-flight copies after quota failure and starts no later copies', async () => {
    const env = setup();
    env.pages.set('source:', { files: Array.from({ length: 9 }, (_, i) => file(`f${i}`)) });
    const copy = env.drive.copyFile;
    env.drive.copyFile = vi.fn(async input => {
      if (input.sourceId === 'f0') throw Object.assign(new Error('storageQuotaExceeded: Drive đã hết dung lượng.'), { fatal: true });
      return copy(input);
    });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('failed');
    expect(env.job.fatalError).toContain('storageQuotaExceeded');
    expect(env.drive.copyFile).toHaveBeenCalledTimes(4);
    expect(env.active).toBe(0);
    expect(env.job.counts.copied).toBe(3);
    expect(Object.keys(env.job.pendingOperations)).toHaveLength(0);
  });

  it.each(['paused', 'cancelled'] as const)('honors %s during a batch after committing all completed requests', async status => {
    const env = setup();
    env.pages.set('source:', { files: Array.from({ length: 9 }, (_, i) => file(`f${i}`)) });
    const copy = env.drive.copyFile;
    env.drive.copyFile = vi.fn(async input => {
      env.job.status = status;
      return copy(input);
    });
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe(status);
    expect(env.drive.copyFile).toHaveBeenCalledTimes(4);
    expect(env.job.counts.copied).toBe(4);
    expect(env.active).toBe(0);
    expect(Object.keys(env.job.pendingOperations)).toHaveLength(0);
  });

  it('does not strand an unsent operation as uncertain when pause arrives at its dispatch checkpoint', async () => {
    const env = setup(file('source'));
    await runCopyJob(env.job, env.drive, {
      persist: async state => {
        await env.persist(state);
        if (Object.values(state.pendingOperations).some(item => item.phase === 'uncertain')) state.status = 'paused';
      },
    });
    expect(env.drive.copyFile).not.toHaveBeenCalled();
    expect(Object.values(env.job.pendingOperations)[0].phase).toBe('prepared');
    env.job.status = 'running';
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('completed');
    expect(env.copies).toHaveLength(1);
  });

  it.each(['source', 'child'])('rejects destination %s inside the source before making mutations', async destinationId => {
    const env = setup();
    env.metadata.set('child', folder('child', { parents: ['source'] }));
    env.job.destinationId = destinationId;
    await runCopyJob(env.job, env.drive, { persist: env.persist });
    expect(env.job.status).toBe('failed');
    expect(env.job.fatalError).toContain('trùng hoặc nằm bên trong');
    expect(env.folders).toHaveLength(0);
    expect(env.copies).toHaveLength(0);
  });

  it('rejects a non-folder destination and an unwritable destination', async () => {
    for (const destination of [file('destination'), folder('destination', { capabilities: { canAddChildren: false } })]) {
      const env = setup();
      env.metadata.set('destination', destination);
      env.job.destinationId = 'destination';
      await runCopyJob(env.job, env.drive, { persist: env.persist });
      expect(env.job.status).toBe('failed');
      expect(env.folders).toHaveLength(0);
    }
  });
});
