import type { AppState } from './types';
export const STATE_KEY = 'driveCopierState';
let cached: Promise<AppState> | undefined;
let writeTail: Promise<void> = Promise.resolve();

export function getState(): Promise<AppState> {
  return cached ??= chrome.storage.local.get(STATE_KEY).then((values) => {
    const state = values[STATE_KEY] as AppState | undefined;
    if (state && state.version !== 1) throw new Error('Phiên bản dữ liệu job không tương thích. Hãy xuất log trước khi xóa dữ liệu extension.');
    return state ?? { version: 1, jobs: [], signedOut: false };
  });
}

/** Snapshot and serialize every checkpoint to prevent out-of-order storage writes. */
export function saveState(state: AppState): Promise<void> {
  const snapshot = structuredClone(state);
  const write = writeTail.then(() => chrome.storage.local.set({ [STATE_KEY]: snapshot }));
  writeTail = write.catch(() => {});
  return write;
}

export function pruneHistory(state: AppState): void {
  const terminal = state.jobs.filter(job => !['queued', 'running', 'paused'].includes(job.status));
  const recentIds = new Set(terminal.slice(-20).map(job => job.id));
  state.jobs = state.jobs.filter(job => {
    if (['queued', 'running', 'paused'].includes(job.status)) return true;
    return recentIds.has(job.id);
  });
}
