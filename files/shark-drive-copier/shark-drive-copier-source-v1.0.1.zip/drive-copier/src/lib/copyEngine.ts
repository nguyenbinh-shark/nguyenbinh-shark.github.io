import {
  FOLDER_MIME,
  SHORTCUT_MIME,
  type CopyJob,
  type DriveAdapter,
  type DriveFile,
  type EngineHooks,
  type PendingOperation,
} from './types';

export interface NewJobInput {
  sourceLink: string;
  sourceId: string;
  sourceResourceKey?: string;
  destinationLink?: string;
  destinationId?: string;
  destinationResourceKey?: string;
  newName?: string;
  ownerPermissionId: string;
  ownerEmail: string;
}

/** Contains only serializable data so the worker can resume any checkpoint. */
export function createJob(input: NewJobInput): CopyJob {
  const now = new Date().toISOString();
  return {
    id: crypto.randomUUID(),
    ...input,
    destinationLink: input.destinationLink ?? '',
    destinationId: input.destinationId || 'root',
    newName: input.newName?.trim() || undefined,
    status: 'queued',
    createdAt: now,
    updatedAt: now,
    initialized: false,
    currentPath: '',
    folderQueue: [],
    fileQueue: [],
    pendingOperations: {},
    folderMap: {},
    copiedSourceIds: [],
    discoveredSourceIds: [],
    skippedSourceIds: [],
    counts: { discovered: 0, copied: 0, folders: 0, skipped: 0 },
    errors: [],
  };
}

interface ErrorFlags {
  fatal?: boolean;
  authRequired?: boolean;
  uncertain?: boolean;
  status?: number;
  reasons?: string[];
}
class PersistenceFailure extends Error {
  constructor(readonly original: unknown) { super('Không lưu được điểm tiếp tục của job.'); }
}

function message(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
function flags(error: unknown): ErrorFlags {
  return typeof error === 'object' && error !== null ? error as ErrorFlags : {};
}
function isTransient(error: unknown): boolean {
  const properties = flags(error);
  return properties.status !== undefined && [0, 429, 500, 503].includes(properties.status)
    || !!properties.reasons?.some(reason => ['rateLimitExceeded', 'userRateLimitExceeded'].includes(reason));
}

/**
 * API retries belong to DriveAdapter. Every mutation carries a durable marker.
 * An uncertain mutation is reconciled before anything else; an absent marker is
 * deliberately left paused because Drive does not offer an idempotency key.
 */
export async function runCopyJob(job: CopyJob, drive: DriveAdapter, hooks: EngineHooks): Promise<void> {
  if (job.status !== 'queued' && job.status !== 'running') return;
  job.status = 'running';
  delete job.fatalError;

  async function checkpoint(): Promise<void> {
    job.updatedAt = new Date().toISOString();
    try { await hooks.persist(job); }
    catch (error) { throw new PersistenceFailure(error); }
    hooks.emit?.(job);
  }

  async function mayContinue(): Promise<boolean> {
    if (job.status === 'running' && hooks.shouldContinue?.() === false) job.status = 'paused';
    if (job.status === 'running') return true;
    if (job.status === 'cancelled') job.finishedAt ??= new Date().toISOString();
    await checkpoint();
    return false;
  }

  // Status can also be changed by background commands during an awaited API
  // call. A function reads the current value without stale TS flow narrowing.
  function isCancelled(): boolean { return job.status === 'cancelled'; }

  function addError(path: string, sourceId: string | undefined, error: unknown): void {
    job.errors.push({ time: new Date().toISOString(), path, sourceId, message: message(error) });
  }

  function discover(file: DriveFile): void {
    if (file.mimeType !== FOLDER_MIME && !job.discoveredSourceIds.includes(file.id)) {
      job.discoveredSourceIds.push(file.id);
      job.counts.discovered++;
    }
  }

  function skip(id: string, path: string, error: unknown): void {
    if (!job.skippedSourceIds.includes(id)) {
      job.skippedSourceIds.push(id);
      job.counts.skipped++;
      addError(path, id, error);
    }
  }

  function removeOperation(operationId: string): void {
    delete job.pendingOperations[operationId];
    job.fileQueue = job.fileQueue.filter(item => item.operationId !== operationId);
  }

  function commit(operation: PendingOperation, result: DriveFile): void {
    if (operation.kind === 'folder') {
      // Checking the map makes committing a reconciled marker safe as well.
      if (!job.folderMap[operation.sourceId!]) {
        job.folderMap[operation.sourceId!] = result.id;
        job.counts.folders++;
        job.folderQueue.push({
          sourceId: operation.sourceId!, destinationId: result.id,
          resourceKey: operation.resourceKey, path: operation.path,
        });
      }
    } else if (!job.copiedSourceIds.includes(operation.sourceId!)) {
      job.copiedSourceIds.push(operation.sourceId!);
      job.counts.copied++;
    }
    if (!job.resultId && operation.sourceId === job.sourceId) {
      job.resultId = result.id;
      job.resultUrl = result.webViewLink ?? (operation.kind === 'folder'
        ? `https://drive.google.com/drive/folders/${result.id}`
        : `https://drive.google.com/file/d/${result.id}/view`);
    }
    removeOperation(operation.operationId);
  }

  function prepare(file: DriveFile, parentId: string, path: string, name = file.name): void {
    const operation: PendingOperation = {
      operationId: crypto.randomUUID(),
      kind: file.mimeType === FOLDER_MIME ? 'folder' : 'file',
      sourceId: file.id, parentId, name, path,
      resourceKey: file.resourceKey, phase: 'prepared',
    };
    job.pendingOperations[operation.operationId] = operation;
    if (operation.kind === 'file') job.fileQueue.push(operation);
  }

  async function resolveShortcut(start: DriveFile): Promise<DriveFile> {
    let file = start;
    const seen = new Set<string>();
    while (file.mimeType === SHORTCUT_MIME) {
      if (seen.has(file.id) || seen.size >= 64) throw new Error('Bỏ qua shortcut tạo vòng lặp.');
      seen.add(file.id);
      const target = file.shortcutDetails;
      if (!target?.targetId) throw new Error('Shortcut không có đối tượng đích có thể truy cập.');
      file = await drive.getFile(target.targetId, target.targetResourceKey);
      file = { ...file, resourceKey: file.resourceKey ?? target.targetResourceKey };
    }
    return file;
  }

  async function validateDestination(source: DriveFile): Promise<void> {
    const destination = await drive.getFile(job.destinationId, job.destinationResourceKey);
    if (destination.mimeType !== FOLDER_MIME) throw new Error('Đích phải là một thư mục Google Drive.');
    if (destination.capabilities?.canAddChildren === false) {
      throw new Error('Bạn không có quyền thêm file vào thư mục đích.');
    }
    job.destinationId = destination.id;
    if (source.mimeType !== FOLDER_MIME) return;
    const ancestors = [destination];
    const seen = new Set<string>();
    while (ancestors.length) {
      const ancestor = ancestors.shift()!;
      if (ancestor.id === source.id) {
        throw new Error('Thư mục đích trùng hoặc nằm bên trong thư mục nguồn. Hãy chọn đích khác.');
      }
      if (seen.has(ancestor.id)) continue;
      seen.add(ancestor.id);
      for (const id of ancestor.parents ?? []) {
        if (!seen.has(id)) ancestors.push(await drive.getFile(id));
      }
    }
  }

  async function reconcile(): Promise<boolean> {
    for (const operation of Object.values(job.pendingOperations)) {
      if (operation.phase !== 'uncertain') continue;
      if (!await mayContinue()) return false;
      job.currentPath = operation.path;
      const existing = await drive.findByOperation(operation.parentId, operation.operationId);
      if (existing) {
        commit(operation, existing);
        await checkpoint();
      } else {
        job.status = 'paused';
        addError(operation.path, operation.sourceId,
          'Chưa xác định được kết quả request trước khi worker dừng. Chưa tìm thấy dấu copy trên Drive; job đã tạm dừng để tránh copy trùng. Có thể Tiếp tục để kiểm tra lại, hoặc kiểm tra thư mục kết quả rồi huỷ job.');
        await checkpoint();
        return false;
      }
    }
    return true;
  }

  async function mutate(operations: PendingOperation[]): Promise<void> {
    // Save uncertain *before* any network mutation. A crash may have happened
    // after Drive committed but before the fetch result reached this worker.
    for (const operation of operations) operation.phase = 'uncertain';
    job.currentPath = operations[0].path;
    await checkpoint();
    if (!await mayContinue()) {
      // No request was dispatched; restoring prepared is safe and lets a
      // later resume send it without pretending that its outcome is unknown.
      for (const operation of operations) operation.phase = 'prepared';
      await checkpoint();
      return;
    }
    const outcomes = await Promise.allSettled(operations.map(operation => Promise.resolve().then(() => operation.kind === 'folder'
      ? drive.createFolder(operation)
      : drive.copyFile(operation))));
    // All requests have settled before controls or fatal outcomes are handled.
    for (let i = 0; i < outcomes.length; i++) {
      const outcome = outcomes[i];
      const operation = operations[i];
      if (outcome.status === 'fulfilled') {
        commit(operation, outcome.value);
        continue;
      }
      const error = outcome.reason as unknown;
      const properties = flags(error);
      if (properties.uncertain) {
        if (job.status === 'running') job.status = 'paused';
        addError(operation.path, operation.sourceId,
          `${message(error)} Kết quả copy chưa xác định; cần kiểm tra dấu copy trước khi tiếp tục.`);
      } else {
        // A definite HTTP failure did not mutate Drive. Auth or exhausted
        // transient failures retain prepared work for a later resume.
        if (!properties.fatal && (properties.authRequired || isTransient(error))) {
          operation.phase = 'prepared';
          if (job.status === 'running') job.status = 'paused';
          addError(operation.path, operation.sourceId, error);
        } else {
          removeOperation(operation.operationId);
          skip(operation.sourceId!, operation.path, error);
          if (operation.sourceId === job.sourceId) {
            job.fatalError = message(error);
            if (job.status !== 'cancelled') job.status = 'failed';
            job.finishedAt = new Date().toISOString();
          }
        }
      }
      if (properties.fatal) {
        job.fatalError = message(error);
        if (job.status !== 'cancelled') job.status = 'failed';
        job.finishedAt = new Date().toISOString();
      }
    }
    await checkpoint();
  }

  try {
    await checkpoint();
    if (!await mayContinue()) return;
    if (!job.initialized) {
      const metadata = await drive.getFile(job.sourceId, job.sourceResourceKey);
      const root = await resolveShortcut({ ...metadata, resourceKey: metadata.resourceKey ?? job.sourceResourceKey });
      if (!await mayContinue()) return;
      await validateDestination(root);
      job.sourceId = root.id;
      job.sourceName = root.name;
      job.sourceResourceKey = root.resourceKey ?? job.sourceResourceKey;
      job.rootKind = root.mimeType === FOLDER_MIME ? 'folder' : 'file';
      job.currentPath = job.newName || root.name;
      job.initialized = true;
      discover(root);
      // Folders are recreated and their children copied individually. A
      // normal Drive folder cannot itself be passed to files.copy, so its
      // canCopy capability must not block traversing readable children.
      if (root.mimeType !== FOLDER_MIME && root.capabilities?.canCopy === false) {
        skip(root.id, job.currentPath, 'Chủ sở hữu chặn copy.');
        job.status = 'failed';
        job.fatalError = 'Chủ sở hữu chặn copy nguồn này.';
        job.finishedAt = new Date().toISOString();
        await checkpoint();
        return;
      }
      prepare(root, job.destinationId, job.currentPath, job.newName || root.name);
      await checkpoint();
    }
    if (!await reconcile()) return;
    while (await mayContinue()) {
      const folderOperation = Object.values(job.pendingOperations)
        .find(item => item.kind === 'folder' && item.phase === 'prepared');
      if (folderOperation) {
        await mutate([folderOperation]);
        continue;
      }
      const files = job.fileQueue.filter(item => item.phase === 'prepared');
      if (files.length >= 4 || (files.length > 0 && job.folderQueue.length === 0)) {
        await mutate(files.slice(0, 4));
        continue;
      }
      const folder = job.folderQueue[0];
      if (!folder) {
        if (Object.keys(job.pendingOperations).length) {
          // Only uncertain operations can remain, e.g. paused before dispatch.
          if (!await reconcile()) return;
          continue;
        }
        job.status = 'completed';
        job.finishedAt = new Date().toISOString();
        job.currentPath = '';
        await checkpoint();
        return;
      }
      job.currentPath = folder.path;
      if (!folder.page) {
        folder.page = await drive.listChildren(folder.sourceId, folder.pageToken, folder.resourceKey);
        folder.index = 0;
        await checkpoint();
        continue;
      }
      if ((folder.index ?? 0) >= folder.page.files.length) {
        const next = folder.page.nextPageToken;
        if (next) {
          folder.pageToken = next;
          delete folder.page;
          delete folder.index;
        } else job.folderQueue.shift();
        await checkpoint();
        continue;
      }
      const entry = folder.page.files[folder.index ?? 0];
      const path = `${folder.path}/${entry.name}`;
      try {
        // A disallowed shortcut must also respect the owner's restriction.
        if (entry.mimeType !== FOLDER_MIME && entry.shortcutDetails?.targetMimeType !== FOLDER_MIME
          && entry.capabilities?.canCopy === false) {
          discover({ ...entry, mimeType: entry.shortcutDetails?.targetMimeType ?? entry.mimeType });
          skip(entry.id, path, 'Chủ sở hữu chặn copy.');
        } else {
          const source = await resolveShortcut(entry);
          discover(source);
          if (source.mimeType !== FOLDER_MIME && source.capabilities?.canCopy === false) skip(source.id, path, 'Chủ sở hữu chặn copy.');
          else if (source.id === job.destinationId || Object.values(job.folderMap).includes(source.id)) {
            skip(source.id, path, 'Bỏ qua thư mục đích/kết quả để tránh copy vòng lặp.');
          } else if (source.mimeType === FOLDER_MIME) {
            if (!job.folderMap[source.id] && !Object.values(job.pendingOperations).some(item => item.sourceId === source.id)) {
              prepare(source, folder.destinationId, path, entry.name);
            }
          } else if (!job.copiedSourceIds.includes(source.id) && !job.skippedSourceIds.includes(source.id)
            && !Object.values(job.pendingOperations).some(item => item.sourceId === source.id)) {
            prepare(source, folder.destinationId, path, entry.name);
          }
        }
      } catch (error) {
        const properties = flags(error);
        if (properties.fatal || properties.authRequired || properties.uncertain) throw error;
        if (isTransient(error)) {
          // Exhausted transient retries while resolving a shortcut do not
          // prove that the item is inaccessible. Preserve the page cursor.
          throw error;
        }
        // A broken/inaccessible shortcut is an individual item error.
        skip(entry.id, path, error);
      }
      // The page cursor and any prepared operation are one checkpoint. Resume
      // cannot forget an item after advancing, or prepare it twice.
      folder.index = (folder.index ?? 0) + 1;
      await checkpoint();
    }
  } catch (error) {
    if (error instanceof PersistenceFailure) throw error.original;
    addError(job.currentPath, job.sourceId, error);
    const properties = flags(error);
    if (!isCancelled()) {
      job.status = properties.fatal || !job.initialized && !properties.authRequired ? 'failed' : 'paused';
    }
    if (job.status === 'failed') {
      job.fatalError = message(error);
      job.finishedAt = new Date().toISOString();
    }
    await checkpoint();
  }
}
