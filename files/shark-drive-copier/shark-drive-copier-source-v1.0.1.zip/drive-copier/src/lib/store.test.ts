import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createJob } from './copyEngine';
import type { AppState, CopyJob } from './types';

function makeJob(id: string, status: CopyJob['status'] = 'completed'): CopyJob {
  return { ...createJob({ sourceLink: 'source123', sourceId: 'source123', ownerEmail: 'test@example.com', ownerPermissionId: 'owner' }), id, status };
}
function makeState(jobs: CopyJob[] = []): AppState { return { version: 1, signedOut: false, jobs }; }

describe('durable job store', () => {
  beforeEach(() => { vi.resetModules(); });
  afterEach(() => { vi.unstubAllGlobals(); });

  it('keeps the newest 20 terminal jobs and every active job in original order', async () => {
    const { pruneHistory } = await import('./store');
    const jobs = Array.from({ length: 25 }, (_, index) => makeJob(`completed-${index}`));
    jobs.splice(2, 0, makeJob('running', 'running'));
    jobs.push(makeJob('paused', 'paused'), makeJob('queued', 'queued'));
    const state = makeState(jobs);
    pruneHistory(state);
    expect(state.jobs.map(job => job.id)).toEqual(['running', ...Array.from({ length: 20 }, (_, index) => `completed-${index + 5}`), 'paused', 'queued']);
  });

  it('takes independent snapshots and serializes writes during concurrent checkpoints', async () => {
    let releaseFirst!: () => void;
    const firstGate = new Promise<void>(resolve => { releaseFirst = resolve; });
    const writes: AppState[] = [];
    const set = vi.fn(async (values: { driveCopierState: AppState }) => {
      writes.push(values.driveCopierState);
      if (writes.length === 1) await firstGate;
    });
    vi.stubGlobal('chrome', { storage: { local: { set } } });
    const { saveState } = await import('./store');
    const state = makeState([makeJob('job')]);
    const first = saveState(state);
    state.jobs[0].counts.copied = 1;
    const second = saveState(state);
    state.jobs[0].counts.copied = 2;
    await Promise.resolve();
    expect(set).toHaveBeenCalledTimes(1);
    expect(writes[0].jobs[0].counts.copied).toBe(0);
    releaseFirst();
    await Promise.all([first, second]);
    expect(writes.map(value => value.jobs[0].counts.copied)).toEqual([0, 1]);
  });

  it('reports a failed checkpoint but allows the next durable write', async () => {
    const set = vi.fn().mockRejectedValueOnce(new Error('Quota exceeded')).mockResolvedValueOnce(undefined);
    vi.stubGlobal('chrome', { storage: { local: { set } } });
    const { saveState } = await import('./store');
    await expect(saveState(makeState())).rejects.toThrow('Quota exceeded');
    await expect(saveState(makeState())).resolves.toBeUndefined();
    expect(set).toHaveBeenCalledTimes(2);
  });

  it('shares one loaded state object across scheduler and command handlers', async () => {
    const stored = makeState([makeJob('job')]);
    const get = vi.fn().mockResolvedValue({ driveCopierState: stored });
    vi.stubGlobal('chrome', { storage: { local: { get } } });
    const { getState } = await import('./store');
    const [first, second] = await Promise.all([getState(), getState()]);
    expect(first).toBe(second);
    expect(get).toHaveBeenCalledTimes(1);
  });
});
