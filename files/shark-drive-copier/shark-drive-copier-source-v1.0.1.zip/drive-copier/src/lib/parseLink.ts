export interface ParsedDriveLink { id: string; resourceKey?: string }
const ID = /^[A-Za-z0-9_-]+$/;

/** Accept Drive links, never arbitrary domains or a string containing an embedded URL. */
export function parseDriveLink(input: string): ParsedDriveLink {
  const value = input.trim();
  if (!value) throw new Error('Vui lòng nhập link hoặc ID Google Drive.');
  if (ID.test(value)) return { id: value };
  let url: URL;
  try { url = new URL(value); } catch { throw new Error('Link Google Drive không hợp lệ.'); }
  if (url.protocol !== 'https:' || url.hostname !== 'drive.google.com' || url.username || url.password || url.port) {
    throw new Error('Chỉ chấp nhận link HTTPS trên drive.google.com hoặc ID trần.');
  }
  const match = url.pathname.match(/\/(?:folders|file\/d|d)\/([A-Za-z0-9_-]+)(?:\/|$)/);
  const id = match?.[1] ?? url.searchParams.get('id');
  if (!id || !ID.test(id)) throw new Error('Không tìm thấy ID file/thư mục trong link Drive.');
  const resourceKey = url.searchParams.get('resourcekey') ?? undefined;
  if (resourceKey && !ID.test(resourceKey)) throw new Error('Resource key trong link không hợp lệ.');
  return { id, ...(resourceKey ? { resourceKey } : {}) };
}

export function parseLink(input: string): string { return parseDriveLink(input).id; }
