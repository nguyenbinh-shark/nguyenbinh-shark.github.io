export const FOLDER_MIME = 'application/vnd.google-apps.folder';
export const SHORTCUT_MIME = 'application/vnd.google-apps.shortcut';

export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  parents?: string[];
  resourceKey?: string;
  webViewLink?: string;
  shortcutDetails?: { targetId: string; targetMimeType: string; targetResourceKey?: string };
  capabilities?: { canCopy?: boolean; canAddChildren?: boolean };
}
export interface FilePage { files: DriveFile[]; nextPageToken?: string }
export interface MutationInput {
  sourceId?: string;
  parentId: string;
  name: string;
  operationId: string;
  resourceKey?: string;
}
export interface DriveAdapter {
  getFile(id: string, resourceKey?: string): Promise<DriveFile>;
  listChildren(id: string, pageToken?: string, resourceKey?: string): Promise<FilePage>;
  findByOperation(parentId: string, operationId: string): Promise<DriveFile | undefined>;
  createFolder(input: MutationInput): Promise<DriveFile>;
  copyFile(input: MutationInput): Promise<DriveFile>;
}

export type JobStatus = 'queued' | 'running' | 'paused' | 'completed' | 'failed' | 'cancelled';
export interface JobError { time: string; path: string; sourceId?: string; message: string }
export interface FolderTask {
  sourceId: string;
  destinationId: string;
  path: string;
  resourceKey?: string;
  pageToken?: string;
  /** A fetched page is durable before its individual entries are processed. */
  page?: FilePage;
  index?: number;
}
export interface PendingOperation extends MutationInput {
  kind: 'folder' | 'file';
  path: string;
  /** Mutations with unknown outcomes must be reconciled before retrying. */
  phase: 'prepared' | 'uncertain';
}
export interface CopyJob {
  id: string;
  sourceLink: string;
  sourceId: string;
  sourceResourceKey?: string;
  sourceName?: string;
  destinationLink: string;
  destinationId: string;
  destinationResourceKey?: string;
  newName?: string;
  ownerPermissionId: string;
  ownerEmail: string;
  status: JobStatus;
  createdAt: string;
  updatedAt: string;
  finishedAt?: string;
  initialized: boolean;
  rootKind?: 'folder' | 'file';
  resultId?: string;
  resultUrl?: string;
  currentPath: string;
  folderQueue: FolderTask[];
  fileQueue: PendingOperation[];
  pendingOperations: Record<string, PendingOperation>;
  folderMap: Record<string, string>;
  copiedSourceIds: string[];
  discoveredSourceIds: string[];
  skippedSourceIds: string[];
  counts: { discovered: number; copied: number; folders: number; skipped: number };
  errors: JobError[];
  fatalError?: string;
}
export interface Account { email: string; displayName: string; permissionId: string }
export interface AppState {
  version: 1;
  jobs: CopyJob[];
  account?: Account;
  signedOut: boolean;
  /** Prevent queued jobs from restarting after a quota/fatal failure. */
  queueBlocked?: boolean;
  sourceDraft?: string;
  sourceDraftRevision?: number;
  notice?: string;
}
export type AppCommand =
  | { type: 'GET_STATE' }
  | { type: 'SIGN_IN' }
  | { type: 'SIGN_OUT' }
  | { type: 'CREATE_JOB'; sourceLink: string; destinationLink: string; newName: string }
  | { type: 'PAUSE_JOB' | 'RESUME_JOB' | 'CANCEL_JOB'; jobId: string }
  | { type: 'OPEN_PANEL'; sourceLink: string };
export type AppReply = { ok: true; state?: AppState } | { ok: false; error: string };

export interface EngineHooks {
  persist(job: CopyJob): Promise<void>;
  emit?(job: CopyJob): void;
  shouldContinue?(): boolean;
}
