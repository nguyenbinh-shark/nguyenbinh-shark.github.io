import { describe, expect, it } from 'vitest';
import { parseDriveLink, parseLink } from './parseLink';

describe('parseLink', () => {
  it.each([
    ['https://drive.google.com/drive/folders/abc_DEF-123', 'abc_DEF-123'],
    ['https://drive.google.com/drive/u/0/folders/folder_1?usp=sharing', 'folder_1'],
    ['https://drive.google.com/file/d/file-1/view?usp=sharing', 'file-1'],
    ['https://drive.google.com/d/doc_1/edit', 'doc_1'],
    ['https://drive.google.com/open?id=file_2', 'file_2'],
    ['  abc_123-xyz  ', 'abc_123-xyz'],
  ])('parses %s', (input, id) => expect(parseLink(input)).toBe(id));
  it('keeps a resource key for shared links', () => expect(parseDriveLink('https://drive.google.com/drive/folders/abc?resourcekey=key-123')).toEqual({ id: 'abc', resourceKey: 'key-123' }));
  it.each(['', 'hello world', 'https://evil.example/folders/abc', 'https://drive.google.com.evil.example/file/d/a', 'http://drive.google.com/file/d/a', 'https://user:pass@drive.google.com/file/d/a', 'https://drive.google.com/drive/my-drive', 'https://drive.google.com/open?id=bad%27id', 'https://drive.google.com/file/d/a?resourcekey=bad%27key'])('rejects %s', (input) => expect(() => parseLink(input)).toThrow());
});
