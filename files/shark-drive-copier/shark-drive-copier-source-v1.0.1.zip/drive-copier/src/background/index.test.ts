import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { AppCommand, AppReply, AppState, CopyJob, EngineHooks } from '../lib/types';

const mocks = vi.hoisted(() => ({
  run: vi.fn(), account: vi.fn(), getToken: vi.fn(), signOut: vi.fn(), setEnabled: vi.fn(),
}));

vi.mock('../lib/driveClient', () => ({
  ChromeAuth: class {
    setEnabled = mocks.setEnabled;
    getToken = mocks.getToken;
    signOut = mocks.signOut;
  },
  DriveClient: class { getAccount = mocks.account; },
}));
vi.mock('../lib/copyEngine', async importOriginal => ({
  ...await importOriginal<typeof import('../lib/copyEngine')>(),
  runCopyJob: mocks.run,
}));

type Listener = (...args: any[]) => unknown;
function event() {
  const listeners: Listener[] = [];
  return {
    listeners,
    addListener: vi.fn((listener: Listener) => { listeners.push(listener); }),
    fire: (...args: any[]) => listeners.map(listener => listener(...args)),
  };
}
function deferred<T = void>() {
  let resolve!: (value: T | PromiseLike<T>) => void;
  const promise = new Promise<T>(done => { resolve = done; });
  return { promise, resolve };
}
const account = { email: 'owner@example.com', displayName: 'Owner', permissionId: 'owner' };
function job(id: string): CopyJob {
  return {
    id, sourceLink: `https://drive.google.com/file/d/source_${id}/view`, sourceId: `source_${id}`,
    destinationLink: '', destinationId: 'root', ownerPermissionId: 'owner', ownerEmail: account.email,
    status: 'queued', createdAt: '2026-10-09T00:00:00Z', updatedAt: '2026-10-09T00:00:00Z',
    initialized: false, currentPath: '', folderQueue: [], fileQueue: [], pendingOperations: {},
    folderMap: {}, copiedSourceIds: [], discoveredSourceIds: [], skippedSourceIds: [],
    counts: { discovered: 0, copied: 0, folders: 0, skipped: 0 }, errors: [],
  };
}

const releases: (() => void)[] = [];
beforeEach(() => {
  vi.resetModules();
  vi.clearAllMocks();
  mocks.account.mockReset().mockResolvedValue(account);
  mocks.getToken.mockReset().mockResolvedValue('token');
  mocks.signOut.mockReset().mockResolvedValue(undefined);
  mocks.setEnabled.mockReset();
  mocks.run.mockReset().mockImplementation(async (item: CopyJob, _drive: unknown, hooks: EngineHooks) => {
    item.status = 'completed';
    item.counts.copied = 1;
    await hooks.persist(item);
  });
});
afterEach(async () => {
  for (const release of releases.splice(0)) release();
  await new Promise(resolve => setTimeout(resolve, 0));
  vi.unstubAllGlobals();
});

async function harness(jobs: CopyJob[], extra: Partial<AppState> = {}) {
  let durable: AppState = structuredClone({ version: 1, jobs, account, signedOut: false, ...extra });
  const snapshots: AppState[] = [];
  const alarms = new Map<string, object>();
  const onMessage = event();
  const onAlarm = event();
  const onStartup = event();
  const onInstalled = event();
  const chromeMock = {
    runtime: {
      id: 'test-id',
      getURL: (path: string) => `chrome-extension://test-id/${path}`,
      getPlatformInfo: vi.fn(async () => ({ os: 'win' })),
      onMessage, onConnect: event(), onStartup, onInstalled,
    },
    storage: { local: {
      get: vi.fn(async () => ({ driveCopierState: structuredClone(durable) })),
      set: vi.fn(async (values: { driveCopierState: AppState }) => {
        durable = structuredClone(values.driveCopierState);
        snapshots.push(durable);
      }),
      setAccessLevel: vi.fn(async () => {}),
    } },
    identity: {
      getAuthToken: vi.fn(async () => ({ token: 'token' })),
      removeCachedAuthToken: vi.fn(async () => {}), clearAllCachedAuthTokens: vi.fn(async () => {}),
    },
    alarms: {
      onAlarm,
      get: vi.fn(async (name: string) => alarms.get(name)),
      create: vi.fn(async (name: string, config: object) => { alarms.set(name, config); }),
      clear: vi.fn(async (name: string) => alarms.delete(name)),
    },
    contextMenus: {
      onClicked: event(), removeAll: vi.fn(async () => {}), create: vi.fn(),
    },
    notifications: {
      create: vi.fn(async () => 'notification-id'), onButtonClicked: event(), onClicked: event(),
    },
    sidePanel: { open: vi.fn(async () => {}), setPanelBehavior: vi.fn(async () => {}) },
    tabs: { create: vi.fn(async () => ({ id: 1 })) },
  };
  vi.stubGlobal('chrome', chromeMock);
  await import('./index');
  const state = await (await import('../lib/store')).getState();
  const send = (command: AppCommand) => new Promise<AppReply>((resolve, reject) => {
    const accepted = onMessage.listeners[0](command, {
      id: 'test-id', url: 'chrome-extension://test-id/sidepanel.html',
    }, resolve);
    if (!accepted) reject(new Error('Message was rejected'));
  });
  return { state, snapshots, chrome: chromeMock, onAlarm, onStartup, onInstalled, send,
    get durable() { return durable; }, get alarms() { return alarms; } };
}

describe('background scheduler', () => {
  it('uses one runner across alarm/startup wakeups and runs queued jobs sequentially', async () => {
    const first = deferred();
    releases.push(() => first.resolve());
    let active = 0;
    let maximum = 0;
    mocks.run.mockImplementation(async (item: CopyJob, _drive: unknown, hooks: EngineHooks) => {
      active++;
      maximum = Math.max(maximum, active);
      if (item.id === 'one') await first.promise;
      item.status = 'completed';
      await hooks.persist(item);
      active--;
    });
    const env = await harness([job('one'), job('two')]);
    await vi.waitFor(() => expect(mocks.run).toHaveBeenCalledTimes(1));
    env.onAlarm.fire({ name: 'drive-copier-resume' });
    env.onStartup.fire();
    env.onAlarm.fire({ name: 'drive-copier-resume' });
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(mocks.run).toHaveBeenCalledTimes(1);
    expect(env.state.jobs.map(item => item.status)).toEqual(['running', 'queued']);
    first.resolve();
    await vi.waitFor(() => expect(env.durable.jobs.map(item => item.status)).toEqual(['completed', 'completed']));
    await vi.waitFor(() => expect(env.alarms.size).toBe(0));
    expect(mocks.run.mock.calls.map(call => call[0].id)).toEqual(['one', 'two']);
    expect(maximum).toBe(1);
    expect(env.chrome.alarms.create).toHaveBeenCalledWith('drive-copier-resume', { periodInMinutes: 1 });
    expect(env.chrome.notifications.create).toHaveBeenCalledTimes(2);
  });

  it('blocks the remaining queue after fatal failure and explicit resume releases that block', async () => {
    mocks.run.mockImplementation(async (item: CopyJob, _drive: unknown, hooks: EngineHooks) => {
      if (item.id === 'one') {
        item.status = 'failed';
        item.fatalError = 'Drive đích đã hết dung lượng.';
      } else item.status = 'completed';
      await hooks.persist(item);
    });
    const env = await harness([job('one'), job('two')]);
    await vi.waitFor(() => expect(env.durable.queueBlocked).toBe(true));
    await vi.waitFor(() => expect(env.alarms.size).toBe(0));
    expect(env.durable.jobs[1].status).toBe('queued');
    env.onAlarm.fire({ name: 'drive-copier-resume' });
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(mocks.run).toHaveBeenCalledTimes(1);
    const reply = await env.send({ type: 'RESUME_JOB', jobId: 'two' });
    expect(reply.ok).toBe(true);
    await vi.waitFor(() => expect(env.durable.jobs[1].status).toBe('completed'));
    expect(env.durable.queueBlocked).toBe(false);
    expect(mocks.run).toHaveBeenCalledTimes(2);
  });

  it('persists authentication failure as paused before engine entry and resumes after sign-in', async () => {
    mocks.account.mockRejectedValueOnce(new Error('Phiên đăng nhập hết hạn.'));
    const env = await harness([job('one'), job('two')]);
    await vi.waitFor(() => expect(env.durable.jobs[0].status).toBe('paused'));
    await vi.waitFor(() => expect(env.alarms.size).toBe(0));
    expect(mocks.run).not.toHaveBeenCalled();
    expect(env.durable.jobs[0].errors[0].message).toContain('hết hạn');
    expect(env.durable.jobs[1].status).toBe('queued');
    expect((await env.send({ type: 'SIGN_IN' })).ok).toBe(true);
    expect(mocks.getToken).toHaveBeenCalledWith(true);
    expect((await env.send({ type: 'RESUME_JOB', jobId: 'one' })).ok).toBe(true);
    await vi.waitFor(() => expect(env.durable.jobs.map(item => item.status)).toEqual(['completed', 'completed']));
    expect(mocks.run.mock.calls.map(call => call[0].id)).toEqual(['one', 'two']);
  });

  it.each(['PAUSE_JOB', 'CANCEL_JOB'] as const)('keeps one active batch when %s is sent and respects the boundary', async type => {
    const batch = deferred();
    releases.push(() => batch.resolve());
    let active = 0;
    let maximum = 0;
    mocks.run.mockImplementation(async (item: CopyJob, _drive: unknown, hooks: EngineHooks) => {
      active++;
      maximum = Math.max(maximum, active);
      if (item.id === 'one') await batch.promise;
      if (hooks.shouldContinue?.()) item.status = 'completed';
      await hooks.persist(item);
      active--;
    });
    const env = await harness([job('one'), job('two')]);
    await vi.waitFor(() => expect(mocks.run).toHaveBeenCalledTimes(1));
    expect((await env.send({ type, jobId: 'one' })).ok).toBe(true);
    env.onAlarm.fire({ name: 'drive-copier-resume' });
    env.onStartup.fire();
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(mocks.run).toHaveBeenCalledTimes(1);
    batch.resolve();
    if (type === 'PAUSE_JOB') {
      await vi.waitFor(() => expect(env.alarms.size).toBe(0));
      expect(env.durable.jobs.map(item => item.status)).toEqual(['paused', 'queued']);
      expect(mocks.run).toHaveBeenCalledTimes(1);
    } else {
      await vi.waitFor(() => expect(env.durable.jobs.map(item => item.status)).toEqual(['cancelled', 'completed']));
      expect(mocks.run).toHaveBeenCalledTimes(2);
    }
    expect(maximum).toBe(1);
    expect(active).toBe(0);
  });

  it('resuming while an existing paused batch settles reuses that runner', async () => {
    const batch = deferred();
    releases.push(() => batch.resolve());
    mocks.run.mockImplementation(async (item: CopyJob, _drive: unknown, hooks: EngineHooks) => {
      await batch.promise;
      if (hooks.shouldContinue?.()) item.status = 'completed';
      await hooks.persist(item);
    });
    const env = await harness([job('one')]);
    await vi.waitFor(() => expect(mocks.run).toHaveBeenCalledTimes(1));
    await env.send({ type: 'PAUSE_JOB', jobId: 'one' });
    await env.send({ type: 'RESUME_JOB', jobId: 'one' });
    expect(env.state.jobs[0].status).toBe('running');
    env.onAlarm.fire({ name: 'drive-copier-resume' });
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(mocks.run).toHaveBeenCalledTimes(1);
    batch.resolve();
    await vi.waitFor(() => expect(env.durable.jobs[0].status).toBe('completed'));
    expect(mocks.run).toHaveBeenCalledTimes(1);
  });

  it('disables auth during sign-out, lets the batch settle, and prevents wakeups or queued commands reacquiring API access', async () => {
    const batch = deferred();
    releases.push(() => batch.resolve());
    mocks.run.mockImplementation(async (item: CopyJob, _drive: unknown, hooks: EngineHooks) => {
      await batch.promise;
      expect(hooks.shouldContinue?.()).toBe(false);
      await hooks.persist(item);
    });
    const env = await harness([job('one'), job('two')]);
    await vi.waitFor(() => expect(mocks.run).toHaveBeenCalledTimes(1));
    const signingOut = env.send({ type: 'SIGN_OUT' });
    await vi.waitFor(() => expect(env.durable.signedOut).toBe(true));
    expect(mocks.setEnabled).toHaveBeenCalledWith(false);
    expect(mocks.signOut).not.toHaveBeenCalled();
    env.onAlarm.fire({ name: 'drive-copier-resume' });
    env.onStartup.fire();
    const createAfterSignOut = env.send({ type: 'CREATE_JOB', sourceLink: 'new_source', destinationLink: '', newName: '' });
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(mocks.account).toHaveBeenCalledTimes(1);
    expect(mocks.run).toHaveBeenCalledTimes(1);
    batch.resolve();
    expect((await signingOut).ok).toBe(true);
    const refused = await createAfterSignOut;
    expect(refused.ok).toBe(false);
    expect(mocks.signOut).toHaveBeenCalledTimes(1);
    await vi.waitFor(() => expect(env.alarms.size).toBe(0));
    env.onAlarm.fire({ name: 'drive-copier-resume' });
    await new Promise(resolve => setTimeout(resolve, 0));
    expect(mocks.account).toHaveBeenCalledTimes(1);
    expect(env.durable.jobs.map(item => item.status)).toEqual(['paused', 'queued']);
    expect(env.durable.account).toBeUndefined();
  });
});
