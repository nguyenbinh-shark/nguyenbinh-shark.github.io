import { ChromeAuth, DriveClient } from '../lib/driveClient';
import { createJob, runCopyJob } from '../lib/copyEngine';
import { parseDriveLink } from '../lib/parseLink';
import { getState, pruneHistory, saveState } from '../lib/store';
import type { AppCommand, AppReply, AppState, CopyJob } from '../lib/types';

const ALARM = 'drive-copier-resume';
const auth = new ChromeAuth();
const ports = new Set<chrome.runtime.Port>();
let runner: Promise<void> | undefined;
let commandTail: Promise<unknown> = Promise.resolve();
let signingOut = false;

function broadcast(state: AppState): void {
  for (const port of ports) {
    try { port.postMessage({ type: 'STATE', state }); } catch { ports.delete(port); }
  }
}

async function checkpoint(state: AppState): Promise<void> {
  await saveState(state);
  broadcast(state);
}

async function syncAlarm(): Promise<void> {
  const state = await getState();
  const active = !state.signedOut && (state.jobs.some(job => job.status === 'running') || !state.queueBlocked && state.jobs.some(job => job.status === 'queued') && !state.jobs.some(job => job.status === 'paused')) || !!runner;
  if (active) {
    // Avoid replacing an existing alarm every checkpoint and postponing its fire time.
    if (!await chrome.alarms.get(ALARM)) await chrome.alarms.create(ALARM, { periodInMinutes: 1 });
  } else await chrome.alarms.clear(ALARM);
}

function kick(): Promise<void> {
  if (runner) return runner;
  runner = scheduler().catch(async error => {
    const state = await getState();
    const message = errorMessage(error);
    for (const job of state.jobs) {
      if (job.status === 'running') {
        job.status = 'paused';
        job.errors.push({ time: new Date().toISOString(), path: job.currentPath, message });
      }
    }
    state.notice = `Job tạm dừng: ${message}`;
    // Keep last durable checkpoint intact if storage itself failed.
    await checkpoint(state).catch(() => broadcast(state));
  }).finally(async () => {
    runner = undefined;
    await syncAlarm().catch(console.error);
  });
  return runner;
}

async function scheduler(): Promise<void> {
  const state = await getState();
  auth.setEnabled(!state.signedOut);
  if (state.signedOut || signingOut) return;
  const heartbeat = setInterval(() => { void chrome.runtime.getPlatformInfo().catch(() => {}); }, 20_000);
  try {
    while (!state.signedOut && !signingOut) {
      let job = state.jobs.find(item => item.status === 'running');
      if (!job) {
        if (state.queueBlocked || state.jobs.some(item => item.status === 'paused')) break;
        job = state.jobs.find(item => item.status === 'queued');
      }
      if (!job) break;
      if (job.status === 'queued') { job.status = 'running'; await checkpoint(state); }
      await syncAlarm();
      try {
        const account = await new DriveClient(auth).getAccount();
        if (account.permissionId !== job.ownerPermissionId) throw new Error('Tài khoản hiện tại khác tài khoản tạo job. Đăng nhập đúng tài khoản rồi Tiếp tục.');
        state.account = account;
        await runCopyJob(job, new DriveClient(auth, { expectedOwner: job.ownerPermissionId }), {
          persist: async () => { await checkpoint(state); },
          emit: () => broadcast(state),
          shouldContinue: () => !state.signedOut && !signingOut && job?.status === 'running',
        });
      } catch (error) {
        if (job.status === 'running') job.status = 'paused';
        job.errors.push({ time: new Date().toISOString(), path: job.currentPath, message: errorMessage(error) });
        await checkpoint(state);
      }
      if (job.status === 'completed' || job.status === 'failed') await notify(job).catch(console.error);
      if (job.status === 'paused') break;
      if (job.status === 'failed' && job.fatalError) {
        state.notice = job.fatalError;
        // Quota/auth failures must not launch the next job into the same failure.
        state.queueBlocked = true;
        await checkpoint(state);
        break;
      }
      pruneHistory(state);
      await checkpoint(state);
    }
  } finally { clearInterval(heartbeat); }
}

async function notify(job: CopyJob): Promise<void> {
  const completed = job.status === 'completed';
  await chrome.notifications.create(`drive-copier:${job.id}`, {
    type: 'basic', iconUrl: 'icons/icon128.png', title: completed ? 'Shark Drive Copier — Hoàn tất' : 'Shark Drive Copier — Job đã dừng',
    message: completed ? `Đã copy ${job.counts.copied} file, tạo ${job.counts.folders} thư mục. Bỏ qua ${job.counts.skipped} mục.` : job.fatalError ?? 'Không thể tiếp tục job. Mở side panel để xem log.',
    ...(job.resultUrl ? { buttons: [{ title: 'Mở kết quả' }] } : {}),
  });
}

async function openNotificationResult(id: string): Promise<void> {
  const state = await getState();
  const job = state.jobs.find(item => `drive-copier:${item.id}` === id);
  if (job?.resultUrl && isDriveUrl(job.resultUrl)) await chrome.tabs.create({ url: job.resultUrl });
}

function errorMessage(error: unknown): string { return error instanceof Error ? error.message : 'Có lỗi xảy ra. Vui lòng xem log và thử lại.'; }
function isDriveUrl(value: string): boolean { try { return new URL(value).origin === 'https://drive.google.com'; } catch { return false; } }
function panelSender(sender: chrome.runtime.MessageSender): boolean { return sender.id === chrome.runtime.id && sender.url === chrome.runtime.getURL('sidepanel.html'); }

async function setDraft(sourceLink: string): Promise<AppReply> {
  parseDriveLink(sourceLink);
  const state = await getState();
  state.sourceDraft = sourceLink;
  state.sourceDraftRevision = (state.sourceDraftRevision ?? 0) + 1;
  await checkpoint(state);
  return { ok: true, state };
}

async function handle(command: AppCommand): Promise<AppReply> {
  const state = await getState();
  if (command.type === 'GET_STATE') return { ok: true, state };
  if (command.type === 'SIGN_IN') {
    if (signingOut) throw new Error('Đang đăng xuất. Vui lòng chờ.');
    await auth.getToken(true);
    state.account = await new DriveClient(auth).getAccount();
    state.signedOut = false;
    state.notice = undefined;
    state.queueBlocked = false;
    await checkpoint(state);
    void kick();
    return { ok: true, state };
  }
  if (command.type === 'SIGN_OUT') {
    signingOut = true;
    state.signedOut = true;
    auth.setEnabled(false);
    for (const job of state.jobs) if (job.status === 'running') job.status = 'paused';
    await checkpoint(state);
    // Let the current bounded batch settle and save before revoking its token.
    try {
      await runner;
      await auth.signOut();
      state.notice = 'Đã đăng xuất và thu hồi quyền Drive.';
    } catch (error) {
      state.notice = errorMessage(error);
    } finally {
      state.account = undefined;
      signingOut = false;
      await checkpoint(state);
      await syncAlarm();
    }
    return { ok: true, state };
  }
  if (command.type === 'CREATE_JOB') {
    if (!state.account || state.signedOut) throw new Error('Hãy Đăng nhập Google trước khi bắt đầu.');
    const source = parseDriveLink(command.sourceLink);
    const destination = command.destinationLink.trim() ? parseDriveLink(command.destinationLink) : { id: 'root' };
    if (command.newName.length > 255) throw new Error('Tên mới quá dài (tối đa 255 ký tự).');
    if (state.jobs.filter(job => ['running', 'queued', 'paused'].includes(job.status)).length >= 50) throw new Error('Hàng chờ đã có 50 job. Hoàn thành hoặc huỷ bớt trước khi thêm.');
    const account = await new DriveClient(auth).getAccount();
    if (account.permissionId !== state.account.permissionId) throw new Error('Tài khoản Chrome đã thay đổi. Hãy Đăng xuất và Đăng nhập lại.');
    const job = createJob({
      sourceLink: command.sourceLink.trim(), sourceId: source.id, sourceResourceKey: source.resourceKey,
      destinationLink: command.destinationLink.trim(), destinationId: destination.id, destinationResourceKey: destination.resourceKey,
      newName: command.newName.trim() || undefined,
      ownerPermissionId: account.permissionId, ownerEmail: account.email,
    });
    state.jobs.push(job);
    state.sourceDraft = undefined;
    state.notice = undefined;
    state.queueBlocked = false;
    pruneHistory(state);
    await checkpoint(state);
    void kick();
    return { ok: true, state };
  }
  if (command.type === 'PAUSE_JOB' || command.type === 'RESUME_JOB' || command.type === 'CANCEL_JOB') {
    const job = state.jobs.find(item => item.id === command.jobId);
    if (!job) throw new Error('Không tìm thấy job.');
    if (['completed', 'failed', 'cancelled'].includes(job.status)) throw new Error('Job đã kết thúc. Bạn có thể tạo job mới.');
    if (command.type === 'PAUSE_JOB') {
      job.status = 'paused';
    } else if (command.type === 'CANCEL_JOB') {
      job.status = 'cancelled';
      job.finishedAt = new Date().toISOString();
    } else {
      if (!state.account || state.signedOut || state.account.permissionId !== job.ownerPermissionId) throw new Error('Hãy đăng nhập tài khoản đã tạo job trước khi Tiếp tục.');
      job.status = state.jobs.some(item => item.id !== job.id && item.status === 'running') ? 'queued' : 'running';
      state.notice = undefined;
      state.queueBlocked = false;
    }
    job.updatedAt = new Date().toISOString();
    await checkpoint(state);
    await syncAlarm();
    void kick();
    return { ok: true, state };
  }
  throw new Error('Lệnh không được hỗ trợ.');
}

chrome.runtime.onMessage.addListener((message: AppCommand, sender, respond: (reply: AppReply) => void) => {
  if (!message || typeof message.type !== 'string' || sender.id !== chrome.runtime.id) return false;
  if (message.type === 'OPEN_PANEL') {
    if (!sender.tab?.id || !sender.url || !isDriveUrl(sender.url) || typeof message.sourceLink !== 'string' || !isDriveUrl(message.sourceLink)) return false;
    // Must invoke synchronously in this user gesture, before storage/auth awaits.
    const opening = chrome.sidePanel.open({ tabId: sender.tab.id });
    void Promise.all([opening, setDraft(message.sourceLink)]).then(([, reply]) => respond(reply), error => respond({ ok: false, error: errorMessage(error) }));
    return true;
  }
  if (!panelSender(sender)) return false;
  const operation = commandTail.then(() => handle(message));
  commandTail = operation.catch(() => {});
  void operation.then(respond, error => respond({ ok: false, error: errorMessage(error) }));
  return true;
});

chrome.runtime.onConnect.addListener(port => {
  if (port.name !== 'drive-copier-ui' || !port.sender || !panelSender(port.sender)) { port.disconnect(); return; }
  ports.add(port);
  port.onDisconnect.addListener(() => ports.delete(port));
  void getState().then(broadcast).catch(console.error);
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!['drive-copier-link', 'drive-copier-page'].includes(String(info.menuItemId)) || tab?.id === undefined) return;
  const url = info.linkUrl ?? info.pageUrl;
  if (!url) return;
  void chrome.sidePanel.open({ tabId: tab.id }).catch(console.error);
  void setDraft(url).catch(async error => {
    const state = await getState();
    state.notice = `Trang Drive này không có ID nguồn. Dán link file/thư mục vào side panel. ${errorMessage(error)}`;
    await checkpoint(state);
  });
});

chrome.notifications.onButtonClicked.addListener((id, index) => { if (index === 0) void openNotificationResult(id).catch(console.error); });
chrome.notifications.onClicked.addListener(id => { void openNotificationResult(id).catch(console.error); });
chrome.alarms.onAlarm.addListener(alarm => { if (alarm.name === ALARM) void kick(); });
chrome.runtime.onStartup.addListener(() => { void boot(); });
chrome.runtime.onInstalled.addListener(() => {
  void chrome.contextMenus.removeAll().then(() => {
    chrome.contextMenus.create({ id: 'drive-copier-link', title: 'Copy vào Drive của tôi', contexts: ['link'], targetUrlPatterns: ['https://drive.google.com/*'] });
    chrome.contextMenus.create({ id: 'drive-copier-page', title: 'Copy vào Drive của tôi', contexts: ['page'], documentUrlPatterns: ['https://drive.google.com/*'] });
  }).catch(console.error);
  void chrome.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(console.error);
  void boot();
});

async function boot(): Promise<void> {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
    await syncAlarm();
    void kick();
  } catch (error) { console.error('Shark Drive Copier:', errorMessage(error)); }
}
// Every worker evaluation resumes durable running jobs, including event-driven wakeups.
void boot();
