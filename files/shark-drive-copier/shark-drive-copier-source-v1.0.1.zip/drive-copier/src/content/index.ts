// Bundled content script; Drive is an SPA, so both URL and DOM changes matter.
const HOST_ID = 'drive-copier-floating-action';
let host: HTMLDivElement | undefined;
let label: HTMLSpanElement | undefined;
let button: HTMLButtonElement | undefined;
let lastUrl = '';
let timer: ReturnType<typeof setTimeout> | undefined;

function supportedUrl(): boolean {
  return location.hostname === 'drive.google.com' && /\/(?:drive\/)?folders\/[a-zA-Z0-9_-]+|\/file\/d\/[a-zA-Z0-9_-]+|\/d\/[a-zA-Z0-9_-]+/.test(location.pathname);
}

function mount(): void {
  if (!supportedUrl()) { host?.remove(); host = undefined; return; }
  if (host?.isConnected) return;
  document.getElementById(HOST_ID)?.remove();
  host = document.createElement('div');
  host.id = HOST_ID;
  host.style.cssText = 'position:fixed;right:22px;bottom:22px;z-index:2147483647;display:block;';
  const shadow = host.attachShadow({ mode: 'closed' });
  const style = document.createElement('style');
  style.textContent = ':host{font-family:Arial,system-ui,sans-serif;color-scheme:light dark}button{display:flex;gap:10px;align-items:center;border:1px solid #185abc;border-radius:24px;background:#1a73e8;color:#fff;font:600 13px Arial,sans-serif;line-height:1.3;padding:13px 17px;box-shadow:0 4px 18px #0003;cursor:pointer;max-width:calc(100vw - 44px)}button:hover{background:#1765cc}button:focus-visible{outline:3px solid #98c4ff;outline-offset:3px}button:disabled{opacity:.75;cursor:wait}.icon{font-size:20px;font-weight:400;line-height:1}span{pointer-events:none}@media(prefers-color-scheme:dark){button{border-color:#739fe1;background:#225eb1;box-shadow:0 4px 18px #0006}button:hover{background:#2c70ce}}@media(max-width:500px){button{font-size:12px;padding:12px 14px}}';
  button = document.createElement('button');
  button.type = 'button';
  button.title = 'Mở Shark Drive Copier để copy file hoặc thư mục đang xem';
  const icon = document.createElement('img');
  icon.className = 'icon';
  icon.src = chrome.runtime.getURL('icons/icon32.png');
  icon.alt = '';
  icon.width = 24;
  icon.height = 24;
  icon.setAttribute('aria-hidden', 'true');
  label = document.createElement('span');
  label.textContent = 'Copy vào Drive của tôi';
  button.append(icon, label);
  button.addEventListener('click', () => {
    const currentButton = button;
    const currentLabel = label;
    if (!currentButton || !currentLabel) return;
    // Do not await another operation before sending: sidePanel.open needs this user gesture.
    const pending = chrome.runtime.sendMessage({ type: 'OPEN_PANEL', sourceLink: location.href });
    currentButton.disabled = true;
    void pending.then((reply: { ok?: boolean; error?: string } | undefined) => {
      if (!reply?.ok) throw new Error(reply?.error || 'Không mở được side panel');
      currentLabel.textContent = 'Đã mở Shark Drive Copier';
    }).catch((error: unknown) => {
      currentLabel.textContent = 'Bấm icon extension để mở';
      currentButton.title = error instanceof Error ? error.message : String(error);
    }).finally(() => {
      currentButton.disabled = false;
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => { currentLabel.textContent = 'Copy vào Drive của tôi'; currentButton.title = 'Mở Shark Drive Copier để copy file hoặc thư mục đang xem'; }, 3500);
    });
  });
  shadow.append(style, button);
  (document.body ?? document.documentElement).append(host);
}

function refresh(): void {
  if (location.href === lastUrl && (host?.isConnected || !supportedUrl())) return;
  lastUrl = location.href;
  mount();
}

let refreshPending = false;
const observer = new MutationObserver(() => {
  // Drive changes thousands of DOM nodes; ignore them while our host remains
  // attached and the route is unchanged instead of scheduling every frame.
  if (location.href === lastUrl && (host?.isConnected || !supportedUrl())) return;
  if (refreshPending) return;
  refreshPending = true;
  requestAnimationFrame(() => { refreshPending = false; refresh(); });
});
observer.observe(document.documentElement, { childList: true, subtree: true });
window.addEventListener('popstate', refresh);
window.addEventListener('hashchange', refresh);
// pushState/replaceState occur in Drive's isolated page world, so polling covers them.
setInterval(() => { if (!document.hidden) refresh(); }, 1500);
refresh();
