import './style.css';
import type { AppCommand, AppReply, AppState, CopyJob, JobStatus } from '../lib/types';

function element<T extends HTMLElement>(id: string): T {
  const found = document.getElementById(id);
  if (!found) throw new Error(`Thiếu phần tử giao diện: ${id}`);
  return found as T;
}

const sourceInput = element<HTMLInputElement>('source-link');
const destinationInput = element<HTMLInputElement>('destination-link');
const nameInput = element<HTMLInputElement>('new-name');
const feedback = element<HTMLParagraphElement>('feedback');
const numberFormat = new Intl.NumberFormat('vi-VN');
const dateFormat = new Intl.DateTimeFormat('vi-VN', { dateStyle: 'short', timeStyle: 'short' });
const statusLabels: Record<JobStatus, string> = {
  queued: 'Đang chờ', running: 'Đang copy', paused: 'Tạm dừng', completed: 'Hoàn tất', failed: 'Đã dừng vì lỗi', cancelled: 'Đã huỷ',
};
let state: AppState | undefined;
let selectedJobId: string | undefined;
let lastDraft: string | undefined;
let lastDraftRevision: number | undefined;
let busy = false;
let reconnectTimer: ReturnType<typeof setTimeout> | undefined;

function showFeedback(message: string, error = false): void {
  feedback.textContent = message;
  feedback.classList.toggle('feedback-error', error);
  feedback.hidden = !message;
}

async function command(message: AppCommand): Promise<AppReply> {
  try {
    const reply = await chrome.runtime.sendMessage(message) as AppReply | undefined;
    if (!reply || typeof reply.ok !== 'boolean') throw new Error('Không nhận được phản hồi. Hãy mở lại side panel.');
    if (reply.ok && reply.state) acceptState(reply.state);
    return reply;
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

async function act(message: AppCommand): Promise<void> {
  if (busy) return;
  busy = true;
  showFeedback(message.type === 'SIGN_IN' ? 'Đang chờ đăng nhập Google… Hoàn tất cửa sổ cấp quyền nếu xuất hiện.' : '');
  render();
  const reply = await command(message);
  busy = false;
  if (!reply.ok) showFeedback(reply.error, true);
  else if (message.type === 'CREATE_JOB') showFeedback('Đã thêm job. Bạn có thể đóng side panel và mở lại để xem tiến độ.');
  render();
}

function acceptState(nextState: AppState): void {
  state = nextState;
  if (nextState.sourceDraft && (nextState.sourceDraft !== lastDraft || nextState.sourceDraftRevision !== lastDraftRevision)) {
    sourceInput.value = nextState.sourceDraft;
    lastDraft = nextState.sourceDraft;
    lastDraftRevision = nextState.sourceDraftRevision;
  }
  render();
}

function currentJob(): CopyJob | undefined {
  const jobs = state?.jobs ?? [];
  const selected = jobs.find((job) => job.id === selectedJobId);
  return selected ?? jobs.find((job) => job.status === 'running') ?? jobs.find((job) => job.status === 'paused') ?? jobs.find((job) => job.status === 'queued') ?? jobs.at(-1);
}

function setStatus(target: HTMLElement, status: JobStatus): void {
  target.textContent = statusLabels[status];
  target.dataset.status = status;
}

function addAction(target: HTMLElement, label: string, type: 'PAUSE_JOB' | 'RESUME_JOB' | 'CANCEL_JOB', jobId: string, danger = false): void {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = `button button-small${danger ? ' button-danger' : ''}`;
  button.textContent = label;
  button.disabled = busy;
  button.addEventListener('click', () => { void act({ type, jobId }); });
  target.append(button);
}

function appendControls(target: HTMLElement, job: CopyJob): void {
  target.replaceChildren();
  if (job.status === 'running' || job.status === 'queued') addAction(target, 'Tạm dừng', 'PAUSE_JOB', job.id);
  if (job.status === 'paused' || job.status === 'queued' && state?.queueBlocked) addAction(target, 'Tiếp tục', 'RESUME_JOB', job.id);
  if (['running', 'queued', 'paused'].includes(job.status)) addAction(target, 'Huỷ', 'CANCEL_JOB', job.id, true);
}

function jobName(job: CopyJob): string { return job.newName || job.sourceName || job.currentPath.split('/').filter(Boolean)[0] || job.sourceId; }

function renderJob(job: CopyJob | undefined): void {
  const card = element<HTMLElement>('job-card');
  card.hidden = !job;
  if (!job) return;
  setStatus(element('job-status'), job.status);
  element('job-name').textContent = jobName(job);
  const { copied, discovered, folders, skipped } = job.counts;
  element('progress-label').textContent = `${numberFormat.format(copied)} / ${numberFormat.format(discovered)} file đã phát hiện`;
  const processed = copied + skipped;
  const percent = job.status === 'completed' ? 100 : discovered > 0 ? Math.min(99, Math.round(processed / discovered * 100)) : 0;
  element('progress-percent').textContent = job.status === 'running' && discovered === 0 ? 'Đang duyệt…' : `${percent}%`;
  const progress = element<HTMLProgressElement>('job-progress');
  progress.value = percent;
  progress.setAttribute('aria-valuetext', `${copied} file đã copy trong ${discovered} file đã phát hiện. Còn đang duyệt thư mục khi job chưa hoàn tất.`);
  element('files-copied').textContent = numberFormat.format(copied);
  element('folders-created').textContent = numberFormat.format(folders);
  element('files-skipped').textContent = numberFormat.format(skipped);
  element('current-path').textContent = job.currentPath || 'Đang chuẩn bị…';
  const fatal = element('job-fatal-error');
  fatal.textContent = job.fatalError ?? '';
  fatal.hidden = !job.fatalError;
  appendControls(element('job-controls'), job);
  const result = element<HTMLAnchorElement>('result-link');
  // API-generated result URLs only; never place an unchecked URL in an anchor.
  const safeResult = job.resultUrl && /^https:\/\/drive\.google\.com\//i.test(job.resultUrl) ? job.resultUrl : undefined;
  result.hidden = !safeResult;
  if (safeResult) result.href = safeResult;
  else result.removeAttribute('href');
  const details = element<HTMLDetailsElement>('error-details');
  details.hidden = job.errors.length === 0;
  element('error-summary').textContent = `Lỗi và mục bỏ qua (${numberFormat.format(job.errors.length)})`;
  const errorList = element<HTMLOListElement>('error-list');
  errorList.replaceChildren();
  for (const error of job.errors.slice(-100)) {
    const item = document.createElement('li');
    item.textContent = error.message;
    const path = document.createElement('p');
    path.textContent = error.path || error.sourceId || 'Nguồn';
    item.append(path);
    errorList.append(item);
  }
  if (job.errors.length > 100) {
    const item = document.createElement('li');
    item.textContent = 'Hiển thị 100 lỗi gần nhất. Xuất log để xem tất cả.';
    errorList.append(item);
  }
}

function renderHistory(jobs: CopyJob[]): void {
  element('history-count').textContent = String(jobs.length);
  element('empty-history').hidden = jobs.length > 0;
  const list = element<HTMLOListElement>('job-history');
  list.replaceChildren();
  for (const job of jobs.slice(-20).reverse()) {
    const item = document.createElement('li');
    item.className = 'history-item';
    item.classList.toggle('selected', job.id === currentJob()?.id);
    const top = document.createElement('div');
    top.className = 'history-item-top';
    const select = document.createElement('button');
    select.type = 'button';
    select.className = 'history-select';
    select.textContent = jobName(job);
    select.title = job.sourceLink;
    select.addEventListener('click', () => { selectedJobId = job.id; render(); element('job-card').scrollIntoView({ behavior: 'smooth', block: 'nearest' }); });
    const status = document.createElement('span');
    status.className = 'status-tag';
    setStatus(status, job.status);
    top.append(select, status);
    const meta = document.createElement('p');
    const created = new Date(job.createdAt);
    const date = Number.isNaN(created.valueOf()) ? '' : dateFormat.format(created);
    meta.textContent = `${date} · ${numberFormat.format(job.counts.copied)} file · ${numberFormat.format(job.counts.folders)} thư mục`;
    item.append(top, meta);
    if (job.ownerEmail && job.ownerEmail !== state?.account?.email) {
      const owner = document.createElement('p');
      owner.textContent = `Tài khoản: ${job.ownerEmail}`;
      item.append(owner);
    }
    if (['queued', 'paused'].includes(job.status)) {
      const controls = document.createElement('div');
      controls.className = 'history-controls';
      appendControls(controls, job);
      item.append(controls);
    }
    list.append(item);
  }
}

function render(): void {
  const signedIn = Boolean(state?.account && !state.signedOut);
  element('account-name').textContent = signedIn ? state!.account!.email : 'Chưa đăng nhập';
  const signIn = element<HTMLButtonElement>('sign-in');
  const signOut = element<HTMLButtonElement>('sign-out');
  signIn.hidden = signedIn;
  signOut.hidden = !signedIn;
  signIn.disabled = busy;
  signOut.disabled = busy;
  const start = element<HTMLButtonElement>('start-job');
  start.disabled = busy;
  const active = state?.jobs.some((job) => ['queued', 'running', 'paused'].includes(job.status));
  start.textContent = busy ? 'Đang xử lý…' : active ? 'Thêm vào hàng chờ' : 'Bắt đầu';
  const notice = element('state-notice');
  notice.textContent = state?.notice ?? '';
  notice.hidden = !state?.notice;
  renderJob(currentJob());
  renderHistory(state?.jobs ?? []);
}

element<HTMLFormElement>('copy-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const sourceLink = sourceInput.value.trim();
  if (!sourceLink) { sourceInput.reportValidity(); return; }
  selectedJobId = undefined;
  void act({ type: 'CREATE_JOB', sourceLink, destinationLink: destinationInput.value.trim(), newName: nameInput.value.trim() });
});
element('sign-in').addEventListener('click', () => { void act({ type: 'SIGN_IN' }); });
element('sign-out').addEventListener('click', () => { void act({ type: 'SIGN_OUT' }); });
element('export-log').addEventListener('click', () => {
  const job = currentJob();
  if (!job) return;
  const lines = ['Shark Drive Copier — Nhật ký job', `Job: ${job.id}`, `Nguồn: ${job.sourceLink}`, `Đích: ${job.destinationLink || 'My Drive'}`, `Tài khoản: ${job.ownerEmail}`, `Trạng thái: ${statusLabels[job.status]}`, `File: ${job.counts.copied}/${job.counts.discovered}; thư mục: ${job.counts.folders}; bỏ qua: ${job.counts.skipped}`, `Kết quả: ${job.resultUrl || 'Chưa có'}`, '', ...job.errors.map((error) => `[${error.time}] ${error.path || error.sourceId || ''}\n${error.message}`)];
  if (job.fatalError) lines.push('', `Lỗi nghiêm trọng: ${job.fatalError}`);
  const url = URL.createObjectURL(new Blob(['\uFEFF', lines.join('\r\n')], { type: 'text/plain;charset=utf-8' }));
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = `drive-copier-${job.id.replace(/[^a-zA-Z0-9_-]/g, '_')}.txt`;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.driveCopierState?.newValue) acceptState(changes.driveCopierState.newValue as AppState);
});

function connect(): void {
  const port = chrome.runtime.connect({ name: 'drive-copier-ui' });
  port.onMessage.addListener((message: { type?: string; state?: AppState }) => {
    if (message.type === 'STATE' && message.state) acceptState(message.state);
  });
  port.onDisconnect.addListener(() => {
    // Reconnect after service-worker suspension, while storage remains the durable source.
    void chrome.runtime.lastError;
    if (reconnectTimer) clearTimeout(reconnectTimer);
    reconnectTimer = setTimeout(connect, 1500);
  });
}

async function initialize(): Promise<void> {
  element('extension-version').textContent = `v${chrome.runtime.getManifest().version}`;
  try {
    const stored = await chrome.storage.local.get('driveCopierState');
    if (stored.driveCopierState) acceptState(stored.driveCopierState as AppState);
  } catch (error) { showFeedback(error instanceof Error ? error.message : String(error), true); }
  connect();
  const reply = await command({ type: 'GET_STATE' });
  if (!reply.ok) showFeedback(reply.error, true);
}
render();
void initialize();
