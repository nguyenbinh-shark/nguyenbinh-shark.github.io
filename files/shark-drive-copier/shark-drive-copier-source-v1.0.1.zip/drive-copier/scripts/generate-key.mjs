import { createHash, generateKeyPairSync } from 'node:crypto';
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const args = process.argv.slice(2);
if (args.includes('--help')) {
  console.log('Cách dùng: npm run keygen [-- --force]\nTạo extension.config.json với public key mới. --force cho phép ghi đè cấu hình.');
  process.exit(0);
}
if (args.some((arg) => arg !== '--force')) {
  console.error('Tham số không hợp lệ. Dùng --help hoặc --force.');
  process.exit(1);
}

const configPath = fileURLToPath(new URL('../extension.config.json', import.meta.url));
const { publicKey } = generateKeyPairSync('rsa', {
  modulusLength: 2048,
  publicKeyEncoding: { type: 'spki', format: 'der' },
  privateKeyEncoding: { type: 'pkcs8', format: 'der' },
});
// Unpacked Chrome derives its extension ID from the first 128 bits of SHA-256
// of the DER public key; hexadecimal digits 0..f become letters a..p.
const extensionId = createHash('sha256')
  .update(publicKey)
  .digest('hex')
  .slice(0, 32)
  .replace(/[0-9a-f]/g, (digit) => String.fromCharCode(97 + Number.parseInt(digit, 16)));
const config = {
  clientId: 'REPLACE_WITH_CHROME_EXTENSION_CLIENT_ID.apps.googleusercontent.com',
  key: publicKey.toString('base64'),
};

try {
  writeFileSync(configPath, `${JSON.stringify(config, null, 2)}\n`, {
    encoding: 'utf8',
    flag: args.includes('--force') ? 'w' : 'wx',
  });
  console.log(`Đã tạo: ${configPath}`);
  console.log(`Extension ID: ${extensionId}`);
  console.log('Điền clientId cho đúng ID này, chạy npm run build và load lại dist/.');
  console.log('Private key không được lưu; public key này chỉ dùng để cố định ID khi phát triển.');
} catch (error) {
  if (error?.code === 'EEXIST') {
    console.error('extension.config.json đã tồn tại. Cấu hình được giữ nguyên.');
    console.error('Nếu muốn đổi key và extension ID, dùng: npm run keygen -- --force');
  } else {
    console.error(`Không thể ghi cấu hình: ${error instanceof Error ? error.message : String(error)}`);
  }
  process.exitCode = 1;
}
