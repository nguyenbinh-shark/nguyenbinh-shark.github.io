import { build } from 'vite';
import { readFile, writeFile, access } from 'node:fs/promises';
import { createHash, createPublicKey } from 'node:crypto';
import { resolve } from 'node:path';

const example = JSON.parse(await readFile('extension.config.example.json', 'utf8'));
const { version } = JSON.parse(await readFile('package.json', 'utf8'));
let config = example;
try { await access('extension.config.json'); config = { ...example, ...JSON.parse(await readFile('extension.config.json', 'utf8')) }; }
catch (error) { if (error.code !== 'ENOENT') throw error; }
if (typeof config.clientId !== 'string' || !config.clientId.endsWith('.apps.googleusercontent.com')) throw new Error('clientId OAuth không hợp lệ.');
const key = Buffer.from(config.key, 'base64');
if (key.length < 100 || key[0] !== 0x30) throw new Error('key phải là public key SPKI DER mã hóa base64. Chạy npm run keygen.');
createPublicKey({ key, format: 'der', type: 'spki' });
await build();
await build({
  configFile: false,
  publicDir: false,
  build: {
    target: 'chrome116', outDir: 'dist', emptyOutDir: false,
    lib: { entry: resolve('src/content/index.ts'), name: 'DriveCopierContent', formats: ['iife'], fileName: () => 'content.js' },
    rollupOptions: { output: { inlineDynamicImports: true } }
  }
});
const manifest = {
  manifest_version: 3,
  name: 'Shark Drive Copier', version, minimum_chrome_version: '116',
  description: 'Copy file và thư mục được chia sẻ vào Google Drive bằng bản sao server-side.',
  key: config.key,
  permissions: ['identity', 'storage', 'alarms', 'contextMenus', 'notifications', 'sidePanel'],
  host_permissions: ['https://www.googleapis.com/*', 'https://drive.google.com/*', 'https://oauth2.googleapis.com/revoke*'],
  oauth2: { client_id: config.clientId, scopes: ['https://www.googleapis.com/auth/drive'] },
  background: { service_worker: 'background.js', type: 'module' },
  action: { default_title: 'Mở Shark Drive Copier', default_icon: { 16: 'icons/icon16.png', 32: 'icons/icon32.png' } },
  side_panel: { default_path: 'sidepanel.html' },
  content_scripts: [{ matches: ['https://drive.google.com/*'], js: ['content.js'], run_at: 'document_idle' }],
  web_accessible_resources: [{ resources: ['icons/icon32.png'], matches: ['https://drive.google.com/*'] }],
  icons: { 16: 'icons/icon16.png', 32: 'icons/icon32.png', 48: 'icons/icon48.png', 128: 'icons/icon128.png' },
  content_security_policy: { extension_pages: "script-src 'self'; object-src 'self'; connect-src https://www.googleapis.com https://oauth2.googleapis.com" }
};
await writeFile('dist/manifest.json', JSON.stringify(manifest, null, 2) + '\n');
const id = [...createHash('sha256').update(key).digest().subarray(0, 16)].flatMap(b => [b >> 4, b & 15]).map(n => String.fromCharCode(97 + n)).join('');
console.log(`Extension ID: ${id}`);
if (config.clientId.startsWith('REPLACE_')) console.warn('Chưa cấu hình OAuth: thay clientId trong extension.config.json rồi build lại. dist vẫn có thể Load unpacked.');
