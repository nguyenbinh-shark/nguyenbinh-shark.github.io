import { mkdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { deflateSync } from 'node:zlib';

const outputDir = fileURLToPath(new URL('../public/icons/', import.meta.url));
mkdirSync(outputDir, { recursive: true });

const crcTable = Array.from({ length: 256 }, (_, value) => {
  let crc = value;
  for (let bit = 0; bit < 8; bit += 1) {
    crc = crc & 1 ? 0xedb88320 ^ (crc >>> 1) : crc >>> 1;
  }
  return crc >>> 0;
});
function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) crc = crcTable[(crc ^ byte) & 255] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
  const name = Buffer.from(type, 'ascii');
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(Buffer.concat([name, data])));
  return Buffer.concat([length, name, data, crc]);
}
function roundedRect(x, y, left, top, width, height, radius) {
  if (x < left || y < top || x > left + width || y > top + height) return false;
  const cx = Math.max(left + radius, Math.min(x, left + width - radius));
  const cy = Math.max(top + radius, Math.min(y, top + height - radius));
  return (x - cx) ** 2 + (y - cy) ** 2 <= radius ** 2;
}
function polygon(x, y, points) {
  let inside = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i, i += 1) {
    const [xi, yi] = points[i];
    const [xj, yj] = points[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}
// One geometric mark is shared by the editable SVG and all PNG sizes.
const shapes = [
  { color: '#bcefff', points: [[.28,.49],[.12,.35],[.16,.52],[.10,.70],[.29,.59]] },
  { color: '#ffffff', points: [[.42,.44],[.48,.20],[.63,.41]] },
  { color: '#bcefff', points: [[.42,.60],[.44,.80],[.62,.66]] },
  { color: '#ffffff', points: [[.18,.56],[.30,.45],[.44,.40],[.58,.37],[.66,.40],[.76,.46],[.86,.53],[.89,.57],[.79,.60],[.64,.68],[.52,.69],[.38,.64],[.28,.58]] },
  { color: '#c7f0ff', points: [[.26,.58],[.44,.57],[.66,.61],[.79,.60],[.64,.68],[.52,.69],[.38,.64]] },
  { color: '#12376d', points: [[.79,.565],[.89,.565],[.86,.585],[.79,.585]] },
  { color: '#39749e', points: [[.59,.47],[.60,.47],[.575,.56],[.565,.56]] },
  { color: '#39749e', points: [[.625,.48],[.635,.48],[.61,.56],[.60,.56]] },
];
const colors = shapes.map(({ color }) => [1, 3, 5].map(i => parseInt(color.slice(i, i + 2), 16)).concat(255));
function sample(x, y) {
  if (!roundedRect(x, y, .025, .025, .95, .95, .22)) return [0, 0, 0, 0];
  let color = [Math.round(16 + 7 * y), Math.round(76 - 36 * y), Math.round(157 - 47 * y), 255];
  for (let i = 0; i < shapes.length; i++) if (polygon(x, y, shapes[i].points)) color = colors[i];
  if ((x - .755) ** 2 + (y - .504) ** 2 <= .017 ** 2) color = [18, 55, 109, 255];
  if (roundedRect(x, y, .66, .715, .15, .16, .022)) color = [99, 229, 227, 255];
  if (roundedRect(x, y, .685, .74, .10, .11, .009)) color = [22, 51, 113, 255];
  if (roundedRect(x, y, .73, .78, .15, .16, .022)) color = [99, 229, 227, 255];
  if (roundedRect(x, y, .755, .805, .10, .11, .009)) color = [22, 45, 111, 255];
  return color;
}
function png(size) {
  const supersampling = 4;
  const pixels = Buffer.alloc(size * (1 + size * 4));
  for (let row = 0; row < size; row += 1) {
    const rowOffset = row * (1 + size * 4);
    pixels[rowOffset] = 0;
    for (let col = 0; col < size; col += 1) {
      const sums = [0, 0, 0, 0];
      for (let sy = 0; sy < supersampling; sy += 1) {
        for (let sx = 0; sx < supersampling; sx += 1) {
          const color = sample((col + (sx + 0.5) / supersampling) / size, (row + (sy + 0.5) / supersampling) / size);
          sums[3] += color[3];
          for (let channel = 0; channel < 3; channel += 1) sums[channel] += color[channel] * color[3];
        }
      }
      const offset = rowOffset + 1 + col * 4;
      for (let channel = 0; channel < 3; channel += 1) pixels[offset + channel] = sums[3] ? Math.round(sums[channel] / sums[3]) : 0;
      pixels[offset + 3] = Math.round(sums[3] / supersampling ** 2);
    }
  }
  const header = Buffer.alloc(13);
  header.writeUInt32BE(size, 0);
  header.writeUInt32BE(size, 4);
  header[8] = 8;
  header[9] = 6;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', header),
    chunk('IDAT', deflateSync(pixels, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

for (const size of [16, 32, 48, 128, 512]) {
  writeFileSync(`${outputDir}/icon${size}.png`, png(size));
}
const polygons = shapes.map(s => `<polygon fill="${s.color}" points="${s.points.map(p => p.map(v => v * 512).join(',')).join(' ')}"/>`).join('\n');
const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" role="img" aria-labelledby="title"><title id="title">Shark Drive Copier</title>
<defs><linearGradient id="bg" x2="0" y2="1"><stop stop-color="#104c9d"/><stop offset="1" stop-color="#17286e"/></linearGradient></defs>
<rect x="12.8" y="12.8" width="486.4" height="486.4" rx="112.64" fill="url(#bg)"/>
${polygons}
<circle cx="386.56" cy="258.048" r="8.704" fill="#12376d"/>
<rect x="337.92" y="366.08" width="76.8" height="81.92" rx="11.264" fill="#63e5e3"/>
<rect x="350.72" y="378.88" width="51.2" height="56.32" rx="4.608" fill="#163371"/>
<rect x="373.76" y="399.36" width="76.8" height="81.92" rx="11.264" fill="#63e5e3"/>
<rect x="386.56" y="412.16" width="51.2" height="56.32" rx="4.608" fill="#162d6f"/>
</svg>\n`;
writeFileSync(`${outputDir}/logo.svg`, svg);
console.log('Đã tạo logo cá mập: SVG và PNG 16/32/48/128/512.');
